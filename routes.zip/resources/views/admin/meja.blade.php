<!-- AC1. HALAMAN MEJA & QR CODE -->

<div class="table-page" style="display: none;">

    <div class="admin-header">

        <div>
            <p class="admin-label">QResto</p>
            <h2>Meja & QR Code</h2>
        </div>

        <button class="table-page-back">
            ←
        </button>

    </div>

    <div class="admin-content">

        <button class="add-table-button">
            + Tambah Meja
        </button>

        <div class="table-grid">

            <!-- MEJA 01 -->
            <div class="table-card">

                <div class="table-card-top">
                    <div class="table-number">
                        Meja 01
                    </div>

                    <span class="table-status available">
                        Tersedia
                    </span>
                </div>

                <div class="qr-placeholder">
                    <div class="qr-symbol">
                        ▦
                    </div>
                    <span>QR Meja 01</span>
                </div>

                <div class="table-actions">

                    <button class="show-qr-button">
                        Lihat QR
                    </button>

                    <button class="delete-table-button">
                        Hapus
                    </button>

                </div>

            </div>


            <!-- MEJA 02 -->
            <div class="table-card">

                <div class="table-card-top">
                    <div class="table-number">
                        Meja 02
                    </div>

                    <span class="table-status occupied">
                        Terisi
                    </span>
                </div>

                <div class="qr-placeholder">
                    <div class="qr-symbol">
                        ▦
                    </div>
                    <span>QR Meja 02</span>
                </div>

                <div class="table-actions">

                    <button class="show-qr-button">
                        Lihat QR
                    </button>

                    <button class="delete-table-button">
                        Hapus
                    </button>

                </div>

            </div>


            <!-- MEJA 03 -->
            <div class="table-card">

                <div class="table-card-top">
                    <div class="table-number">
                        Meja 03
                    </div>

                    <span class="table-status available">
                        Tersedia
                    </span>
                </div>

                <div class="qr-placeholder">
                    <div class="qr-symbol">
                        ▦
                    </div>
                    <span>QR Meja 03</span>
                </div>

                <div class="table-actions">

                    <button class="show-qr-button">
                        Lihat QR
                    </button>

                    <button class="delete-table-button">
                        Hapus
                    </button>

                </div>

            </div>


            <!-- MEJA 04 -->
            <div class="table-card">

                <div class="table-card-top">
                    <div class="table-number">
                        Meja 04
                    </div>

                    <span class="table-status available">
                        Tersedia
                    </span>
                </div>

                <div class="qr-placeholder">
                    <div class="qr-symbol">
                        ▦
                    </div>
                    <span>QR Meja 04</span>
                </div>

                <div class="table-actions">

                    <button class="show-qr-button">
                        Lihat QR
                    </button>

                    <button class="delete-table-button">
                        Hapus
                    </button>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- AC3. JAVASCRIPT MEJA & QR CODE -->

<script>
    const halamanMeja =
        document.querySelector(".table-page");

    const tombolKembaliMeja =
        document.querySelector(".table-page-back");

    const tombolTambahMeja =
        document.querySelector(".add-table-button");

    const daftarMeja =
        document.querySelector(".table-grid");


    // TAMBAH MEJA
    tombolTambahMeja.addEventListener("click", function () {

        const jumlahMeja =
            document.querySelectorAll(".table-card").length + 1;

        const namaMeja =
            "Meja " + String(jumlahMeja).padStart(2, "0");

        const mejaBaru =
            document.createElement("div");

        mejaBaru.className = "table-card";

        mejaBaru.innerHTML = `
            <div class="table-card-top">

                <div class="table-number">
                    ${namaMeja}
                </div>

                <span class="table-status available">
                    Tersedia
                </span>

            </div>

            <div class="qr-placeholder">

                <div class="qr-symbol">
                    ▦
                </div>

                <span>QR ${namaMeja}</span>

            </div>

            <div class="table-actions">

                <button class="show-qr-button">
                    Lihat QR
                </button>

                <button class="delete-table-button">
                    Hapus
                </button>

            </div>
        `;

        daftarMeja.appendChild(mejaBaru);

        aktifkanTombolMeja(mejaBaru);

        alert(
            namaMeja +
            " berhasil ditambahkan!"
        );

    });


    // FUNGSI TOMBOL MEJA
    function aktifkanTombolMeja(meja) {

        const tombolLihatQR =
            meja.querySelector(".show-qr-button");

        const tombolHapus =
            meja.querySelector(".delete-table-button");


        // LIHAT QR
        tombolLihatQR.addEventListener(
            "click",
            function () {

                const nama =
                    meja.querySelector(
                        ".table-number"
                    ).textContent.trim();

                alert(
                    "QR Code " +
                    nama +
                    "\n\n" +
                    "QR Code meja akan digunakan " +
                    "oleh pelanggan untuk membuka menu."
                );

            }
        );


        // HAPUS MEJA
        tombolHapus.addEventListener(
            "click",
            function () {

                const nama =
                    meja.querySelector(
                        ".table-number"
                    ).textContent.trim();

                const yakin =
                    confirm(
                        "Hapus " +
                        nama +
                        "?"
                    );

                if (yakin) {

                    meja.remove();

                    alert(
                        nama +
                        " berhasil dihapus!"
                    );

                }

            }
        );

    }


    // AKTIFKAN TOMBOL MEJA YANG SUDAH ADA
    document
        .querySelectorAll(".table-card")
        .forEach(function (meja) {

            aktifkanTombolMeja(meja);

        });


    // KEMBALI KE DASHBOARD
    tombolKembaliMeja.addEventListener(
        "click",
        function () {

            halamanMeja.style.display = "none";

            document.querySelector(
                ".admin-page"
            ).style.display = "block";

        }
    );

</script>

<!-- AC4. HUBUNGKAN DASHBOARD ADMIN KE MEJA & QR -->

<script>
    const semuaMenuAdmin =
        document.querySelectorAll(".admin-menu-card");

    const tombolMejaQR =
        semuaMenuAdmin[2];

    tombolMejaQR.addEventListener("click", function () {

        document.querySelector(".admin-page").style.display = "none";

        halamanMeja.style.display = "block";

    });
</script>