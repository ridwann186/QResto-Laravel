
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir QResto</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 20px;
            background: #f7f7f7;
            font-family: Arial, sans-serif;
            color: #222;
        }

        .kasir-container {
            max-width: 650px;
            margin: 30px auto;
            padding: 25px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 2px 12px rgba(0,0,0,.06);
        }

        .kasir-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
        }

        .kasir-header h1 {
            margin: 0;
            font-size: 25px;
        }

        .kasir-header p {
            margin: 7px 0 0;
            color: #777;
        }

        .kasir-back {
            padding: 10px 15px;
            border: 0;
            border-radius: 10px;
            background: #eee;
            cursor: pointer;
        }

        #reader {
            width: 100%;
            max-width: 400px;
            margin: 20px auto;
        }

        .hasil-pesanan-kasir {
            margin-top: 20px;
            padding: 20px;
            border: 1px solid #eee;
            border-radius: 15px;
        }

        .hasil-pesanan-kasir p {
            line-height: 1.6;
        }

        .item-pesanan-scan {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            padding: 10px 0;
        }

        #tombolBayarKasir {
            width: 100%;
            margin-top: 15px;
            padding: 14px;
            border: 0;
            border-radius: 12px;
            background: #28a745;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        #statusBayarScan {
            font-weight: bold;
        }

        .pesan-error {
            color: #c0392b;
        }
    </style>
</head>

<body>

<div class="kasir-container">

    <div class="kasir-header">
        <div>
            <h1>QResto - Kasir</h1>
            <p>Scan QR pesanan pelanggan</p>
        </div>

        <button class="kasir-back" onclick="location.href='/'">
            Kembali
        </button>
    </div>

    <h3>Scan QR Pesanan</h3>
    <p>Arahkan kamera ke QR yang ditampilkan pelanggan.</p>

    <div id="reader"></div>
    <div id="hasilScanPesanan"></div>

</div>

<script src="https://www.gstatic.com/firebasejs/12.1.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore-compat.js"></script>
<script src="https://unpkg.com/html5-qrcode"></script>

<script>
const firebaseConfig = {
    apiKey: "AIzaSyB2uWshxlnZWqwGu1yEc1TvMsDGCph40-o",
    authDomain: "qresto-510b7.firebaseapp.com",
    projectId: "qresto-510b7",
    storageBucket: "qresto-510b7.firebasestorage.app",
    messagingSenderId: "125444042497",
    appId: "1:125444042497:web:c6e118614a40631cf1f500",
    measurementId: "G-CFCNW50JC2"
};

if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

const db = firebase.firestore();
const hasilScanPesanan = document.getElementById("hasilScanPesanan");

async function cariPesananFirestore(nomorPesanan) {
    try {
        const nomorBersih = String(nomorPesanan || "")
            .trim()
            .replace(/^#+/, "");

        if (!nomorBersih) return null;

        const kandidat = ["#" + nomorBersih, nomorBersih];

        for (const nomor of kandidat) {
            const snapshot = await db
                .collection("pesanan")
                .doc(nomor)
                .get();

            if (snapshot.exists) {
                return snapshot.data();
            }
        }

        return null;
    } catch (error) {
        console.error("Gagal mencari pesanan:", error);
        throw error;
    }
}

async function bayarPesananKasir(nomorPesanan) {
    try {
        const nomorAsli = String(nomorPesanan).trim();
        const tanpaPagar = nomorAsli.replace(/^#+/, "");

        const kandidat = [
            ...new Set([
                nomorAsli,
                "#" + tanpaPagar,
                tanpaPagar
            ])
        ];

        for (const nomor of kandidat) {
            const docRef = db.collection("pesanan").doc(nomor);
            const snapshot = await docRef.get();

            if (snapshot.exists) {
                await docRef.update({
                    statusPembayaran: "Dibayar",
                    waktuPembayaran: new Date()
                });

                return true;
            }
        }

        return false;
    } catch (error) {
        console.error("Gagal memperbarui pembayaran:", error);
        throw error;
    }
}

async function tampilkanPesananHasilScan(nomorPesanan) {
    hasilScanPesanan.innerHTML = "<p>Memeriksa pesanan...</p>";

    try {
        const pesanan = await cariPesananFirestore(nomorPesanan);

        if (!pesanan) {
            hasilScanPesanan.innerHTML = `
                <div class="hasil-pesanan-kasir">
                    <h3>Pesanan Tidak Ditemukan</h3>
                    <p>Nomor pesanan: ${nomorPesanan}</p>
                </div>
            `;
            return;
        }

        const nomor = pesanan.nomorPesanan || nomorPesanan;
        const items = Array.isArray(pesanan.items) ? pesanan.items : [];
        const metode = pesanan.metodePembayaran || "Kasir";
        const statusBayar = pesanan.statusPembayaran || "Belum Dibayar";
        const total = Number(String(pesanan.total || 0).replace(/[^\d]/g, ""));

        hasilScanPesanan.innerHTML = `
            <div class="hasil-pesanan-kasir">
                <h3>${nomor}</h3>
                <p>
                    Meja: ${pesanan.meja || "-"}<br>
                    Jenis: ${pesanan.jenisPesanan || "-"}<br>
                    Status pesanan: ${pesanan.status || "Baru"}
                </p>

                <h4>Detail Pesanan</h4>

                ${
                    items.map(item => {
                        const jumlah = Number(item.jumlah) || 1;
                        const harga = Number(
                            String(item.harga || 0).replace(/[^\d]/g, "")
                        );

                        return `
                            <div class="item-pesanan-scan">
                                <span>${item.nama || "Menu"} × ${jumlah}</span>
                                <strong>Rp${harga.toLocaleString("id-ID")}</strong>
                            </div>
                        `;
                    }).join("")
                }

                <hr>
                <h3>Total: Rp${total.toLocaleString("id-ID")}</h3>
                <p>Metode pembayaran: ${metode}</p>
                <p>Status pembayaran:
                    <span id="statusBayarScan">${statusBayar}</span>
                </p>

                ${
                    metode.toLowerCase().includes("kasir") &&
                    statusBayar !== "Dibayar"
                    ? `<button id="tombolBayarKasir">✓ Tandai Sudah Dibayar</button>`
                    : ""
                }
            </div>
        `;

        const tombolBayar = document.getElementById("tombolBayarKasir");

        if (tombolBayar) {
            tombolBayar.onclick = async function () {
                tombolBayar.disabled = true;
                tombolBayar.textContent = "Memproses...";

                try {
                    const berhasil = await bayarPesananKasir(nomor);

                    if (!berhasil) {
                        throw new Error("Pesanan tidak ditemukan di Firebase.");
                    }

                    document.getElementById("statusBayarScan").textContent = "Dibayar";
                    tombolBayar.remove();

                    alert("Pembayaran berhasil dikonfirmasi.");
                } catch (error) {
                    tombolBayar.disabled = false;
                    tombolBayar.textContent = "✓ Tandai Sudah Dibayar";
                    alert("Gagal memperbarui pembayaran: " + error.message);
                }
            };
        }

    } catch (error) {
        hasilScanPesanan.innerHTML = `
            <div class="hasil-pesanan-kasir">
                <h3>Gagal Mengambil Pesanan</h3>
                <p class="pesan-error">${error.message}</p>
            </div>
        `;
    }
}

let scannerPesanan = null;
let scannerSedangBerjalan = false;

async function mulaiScannerPesanan() {
    if (scannerSedangBerjalan) return;

    scannerSedangBerjalan = true;
    scannerPesanan = new Html5Qrcode("reader");

    try {
        await scannerPesanan.start(
            { facingMode: "environment" },
            { fps: 10, qrbox: 250 },
            async function (hasil) {
                await scannerPesanan.stop();
                scannerSedangBerjalan = false;

                await tampilkanPesananHasilScan(hasil.trim());
            },
            function () {
                // Kesalahan scan sementara diabaikan.
            }
        );
    } catch (error) {
        scannerSedangBerjalan = false;
        hasilScanPesanan.innerHTML =
            "<p class='pesan-error'>Kamera tidak dapat dibuka: " +
            error.message + "</p>";
    }
}

mulaiScannerPesanan();
</script>

</body>
</html>
