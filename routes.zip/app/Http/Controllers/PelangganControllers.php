<?php

namespace App\Http\Controllers;

class PelangganControllers extends Controller
{
    public function home()
    {
        return view('pelanggan.home', [
            'jenisPesanan' => null,
            'nomorMeja' => null
        ]);
    }

    // QR TAKE AWAY
    public function takeaway()
    {
        return view('pelanggan.home', [
            'jenisPesanan' => 'Takeaway',
            'nomorMeja' => null
        ]);
    }

    // QR DINE IN
    public function meja($nomorMeja)
    {
        // Hanya menerima nomor meja
        if (!preg_match('/^[0-9]{1,3}$/', $nomorMeja)) {
            abort(404);
        }

        $nomorMeja = str_pad($nomorMeja, 2, '0', STR_PAD_LEFT);

        return view('pelanggan.home', [
            'jenisPesanan' => 'Dine In',
            'nomorMeja' => 'Meja ' . $nomorMeja
        ]);
    }
}
