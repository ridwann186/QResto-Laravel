<?php

namespace App\Http\Controllers;

class KasirControllers extends Controller
{
    public function index()
    {
        return view('kasir.pesanan');
    }

    public function scan()
    {
        return view('kasir.scan');
    }

    public function pesanan()
    {
        return view('kasir.pesanan');
    }
}