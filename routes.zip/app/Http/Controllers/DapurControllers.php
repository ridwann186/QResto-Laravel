<?php

namespace App\Http\Controllers;

class DapurControllers extends Controller
{
    public function index()
    {
        return view('dapur.index');
    }
}