<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QResto - Kasir</title>

    <script src="https://unpkg.com/html5-qrcode"></script>
    <script src="https://www.gstatic.com/firebasejs/12.1.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore-compat.js"></script>
    <style>
    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background: #f7f7f7;
        color: #222;
    }

    .app {
        width: 100%;
        min-height: 100vh;
        background: #f7f7f7;
    }

    .admin-header {
        padding: 22px 25px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #fff;
        border-bottom: 1px solid #eee;
    }

    .admin-label {
        margin: 0 0 4px;
        color: #ff7a00;
        font-size: 11px;
        font-weight: bold;
        letter-spacing: 1px;
    }

    .admin-header h2 {
        margin: 0;
        font-size: 22px;
    }

    .admin-content {
        padding: 20px 25px 35px;
        max-width: 1100px;
        margin: 0 auto;
    }

    .cashier-scanner {
        padding: 20px;
        margin-bottom: 20px;
        background: #fff;
        border: 1px solid #eee;
        border-radius: 17px;
    }

    .cashier-scanner h3 {
        margin-top: 0;
    }

    #reader {
        width: 100%;
        max-width: 400px;
        margin: 20px auto;
    }

    @media (max-width: 600px) {
        .admin-header {
            padding: 18px 15px;
        }

        .admin-content {
            padding: 18px 15px 30px;
        }

        .cashier-scanner {
            padding: 15px;
        }
    }
</style>
</head>

<body>

    <div class="app">

        <!-- HEADER KASIR -->
        <div class="admin-header">
            <div>
                <p class="admin-label">QResto</p>
                <h2>Kasir</h2>
            </div>
        </div>

        <div class="admin-content">

            <!-- SCANNER QR PESANAN -->
            <div class="cashier-scanner">
                <h3>Scan QR Pesanan</h3>

                <p>
                    Arahkan kamera ke QR yang ditampilkan pelanggan.
                </p>

                <div id="reader"></div>

                <div id="hasilScanPesanan"></div>
            </div>

        </div>

    </div>
    
    <script>
/* =====================================
   KONEKSI FIREBASE QResto
   ===================================== */

const firebaseConfig = {
    apiKey: "AIzaSyB2uWshxlnZWqwGu1yEc1TvMsDGCph40-o",
    authDomain: "qresto-510b7.firebaseapp.com",
    projectId: "qresto-510b7",
    storageBucket: "qresto-510b7.firebasestorage.app",
    messagingSenderId: "125444042497",
    appId: "1:125444042497:web:c6e118614a40631cf1f500",
    measurementId: "G-CFCNW50JC2"
};

if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

const dbKasir = firebase.firestore();
const hasilScan = document.getElementById("hasilScanPesanan");

let scannerPesanan = null;
let sedangMemprosesScan = false;


/* =====================================
   FUNGSI PENCARIAN PESANAN FIREBASE
   ===================================== */

async function cariPesananKasir(nomorQR) {
    const teksQR = String(nomorQR || "").trim();

    // Jika QR berisi URL, ambil bagian terakhirnya.
    let nomor = teksQR;

    try {
        if (/^https?:\/\//i.test(teksQR)) {
            const url = new URL(teksQR);
            nomor = decodeURIComponent(
                url.pathname.split("/").filter(Boolean).pop() || ""
            );
        }
    } catch (error) {
        console.warn("QR bukan URL yang valid:", error);
    }

    // Bersihkan karakter pagar dan spasi.
    nomor = nomor.trim().replace(/^#+/, "");

    if (!nomor) {
        throw new Error("Nomor pesanan pada QR kosong.");
    }

    // Coba ID dokumen dengan dan tanpa tanda pagar.
    const kandidat = [...new Set([
        nomor,
        "#" + nomor
    ])];

    for (const idDokumen of kandidat) {
        const dokumen = await dbKasir
            .collection("pesanan")
            .doc(idDokumen)
            .get();

        console.log(
            "Mencari pesanan:",
            idDokumen,
            "| Ditemukan:",
            dokumen.exists
        );

        if (dokumen.exists) {
            return {
                idDokumen: dokumen.id,
                data: dokumen.data()
            };
        }
    }

    return null;
}


/* =====================================
   TAMPILKAN DETAIL PESANAN
   ===================================== */

function formatRupiah(nilai) {
    const angka = Number(
        String(nilai ?? 0).replace(/[^\d.-]/g, "")
    ) || 0;

    return "Rp" + angka.toLocaleString("id-ID");
}

function teksAman(nilai) {
    return String(nilai ?? "").replace(/[&<>"']/g, karakter => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    })[karakter]);
}

function tampilkanDetailPesanan(idDokumen, pesanan) {
    const daftarItem = Array.isArray(pesanan.items)
        ? pesanan.items
        : [];

    const statusBayar = pesanan.statusPembayaran || "Belum Dibayar";
    const metodeBayar = pesanan.metodePembayaran || "Kasir";

    const daftarHTML = daftarItem.length
        ? daftarItem.map(item => {
            const nama = item.nama || item.namaMenu || item.name || "Menu";
            const jumlah = Number(item.jumlah ?? item.qty ?? 1) || 1;
            const harga = Number(item.harga ?? item.price ?? 0) || 0;
            const subtotal = Number(item.subtotal ?? (harga * jumlah)) || 0;

            return `
                <div style="padding:10px 0;border-bottom:1px solid #eee;">
                    <div style="font-weight:600;">${teksAman(nama)}</div>
                    <div style="font-size:14px;color:#666;">
                        ${jumlah} × ${formatRupiah(harga)}
                    </div>
                    <div style="font-weight:600;">
                        ${formatRupiah(subtotal)}
                    </div>
                </div>
            `;
        }).join("")
        : "<p>Daftar item tidak ditemukan atau format item berbeda.</p>";

    const total = pesanan.total ?? pesanan.totalHarga ?? 0;
    const sudahDibayar = statusBayar.toLowerCase() === "dibayar";
    const bukanBayarKasir = !String(metodeBayar).toLowerCase().includes("kasir");

    hasilScan.innerHTML = `
        <div style="margin-top:20px;padding:18px;background:#fff;border:1px solid #eee;border-radius:14px;">
            <h3 style="margin-top:0;">Detail Pesanan</h3>

            <p>
                <strong>Nomor:</strong>
                ${teksAman(pesanan.nomorPesanan || idDokumen)}
            </p>

            <p>
                <strong>Metode pembayaran:</strong>
                ${teksAman(metodeBayar)}
            </p>

            <div style="margin:15px 0;">
                ${daftarHTML}
            </div>

            <h3>Total: ${formatRupiah(total)}</h3>

            <p>
                <strong>Status pembayaran:</strong>
                <span id="statusBayarScan">${teksAman(statusBayar)}</span>
            </p>

            ${
                sudahDibayar
                    ? '<p style="color:green;font-weight:bold;">Pembayaran sudah dikonfirmasi.</p>'
                    : bukanBayarKasir
                        ? '<p>Pesanan ini tidak menggunakan metode Bayar di Kasir.</p>'
                        : '<button id="tombolBayarKasir" type="button" style="padding:12px 16px;background:#ff7a00;color:white;border:0;border-radius:8px;cursor:pointer;font-weight:bold;">✓ Tandai Sudah Dibayar</button>'
            }
        </div>
    `;

    const tombol = document.getElementById("tombolBayarKasir");

    if (tombol) {
        tombol.addEventListener("click", async () => {
            if (!confirm("Konfirmasi bahwa pembayaran pesanan ini sudah diterima?")) {
                return;
            }

            tombol.disabled = true;
            tombol.textContent = "Memproses pembayaran...";

            try {
                const dokumen = dbKasir
                    .collection("pesanan")
                    .doc(idDokumen);

                const terbaru = await dokumen.get();

                if (!terbaru.exists) {
                    throw new Error("Pesanan tidak ditemukan lagi.");
                }

                if (terbaru.data().statusPembayaran === "Dibayar") {
                    document.getElementById("statusBayarScan").textContent = "Dibayar";
                    tombol.remove();
                    alert("Pesanan ini sudah dibayar sebelumnya.");
                    return;
                }

                await dokumen.update({
                    statusPembayaran: "Dibayar",
                    waktuPembayaran: firebase.firestore.FieldValue.serverTimestamp()
                });

                document.getElementById("statusBayarScan").textContent = "Dibayar";
                tombol.remove();

                alert("Pembayaran berhasil dikonfirmasi!");

            } catch (error) {
                console.error("Gagal memperbarui pembayaran:", error);
                alert("Gagal mengubah pembayaran. Periksa koneksi dan aturan akses Firebase.");
                tombol.disabled = false;
                tombol.textContent = "✓ Tandai Sudah Dibayar";
            }
        });
    }
}


/* =====================================
   PROSES QR YANG DIPINDAI
   ===================================== */

async function prosesHasilScan(teksQR) {
    hasilScan.innerHTML = "<p>Sedang mencari pesanan di Firebase...</p>";

    try {
        const hasil = await cariPesananKasir(teksQR);

        if (!hasil) {
            hasilScan.innerHTML = `
                <div style="margin-top:15px;padding:15px;background:#fff;border:1px solid #eee;border-radius:12px;">
                    <h3>Pesanan Tidak Ditemukan</h3>
                    <p>Isi QR: ${teksAman(teksQR)}</p>
                    <p>Pastikan QR berisi nomor pesanan yang tersimpan di koleksi <code>pesanan</code>.</p>
                </div>
            `;
            return;
        }

        tampilkanDetailPesanan(hasil.idDokumen, hasil.data);

    } catch (error) {
        console.error("Gagal mencari pesanan:", error);
        hasilScan.innerHTML = `
            <p style="color:#b91c1c;">
                Gagal mengambil pesanan dari Firebase.
                Periksa koneksi internet dan konfigurasi Firebase.
            </p>
        `;
    }
}


/* =====================================
   AKTIFKAN KAMERA SCANNER
   ===================================== */

async function mulaiScannerKasir() {
    if (scannerPesanan) return;

    if (typeof Html5Qrcode === "undefined") {
        hasilScan.textContent = "Library pemindai QR gagal dimuat.";
        return;
    }

    scannerPesanan = new Html5Qrcode("reader");

    try {
        await scannerPesanan.start(
            { facingMode: "environment" },
            { fps: 10, qrbox: { width: 250, height: 250 } },
            async (teksQR) => {
                if (sedangMemprosesScan) return;

                sedangMemprosesScan = true;

                try {
                    await scannerPesanan.stop();
                    await prosesHasilScan(teksQR);
                } catch (error) {
                    console.error("Kesalahan saat memindai:", error);
                    hasilScan.textContent = "Pemindaian gagal. Muat ulang halaman lalu coba lagi.";
                }
            },
            () => {}
        );
    } catch (error) {
        console.error("Kamera tidak dapat diaktifkan:", error);
        hasilScan.textContent =
            "Kamera tidak dapat diaktifkan. Izinkan akses kamera dan buka halaman melalui localhost atau HTTPS.";
        scannerPesanan = null;
    }
}

mulaiScannerKasir();
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\QResto\resources\views/kasir.blade.php ENDPATH**/ ?>