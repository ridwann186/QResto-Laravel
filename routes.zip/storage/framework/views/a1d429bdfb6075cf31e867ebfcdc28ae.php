<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QResto — Nikmati Setiap Sajian</title>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap');

        :root {
            --green: #244b3b;
            --green-light: #e8f0e9;
            --cream: #faf8f2;
            --orange: #d98b45;
            --text: #292d29;
            --muted: #777d76;
            --white: #ffffff;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--cream);
            color: var(--text);
            font-family: 'DM Sans', sans-serif;
        }

        button, a {
            font: inherit;
        }

        a {
            color: inherit;
            text-decoration: none;
        }

        .navbar {
            height: 78px;
            padding: 0 7%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--cream);
            border-bottom: 1px solid #e9e6dd;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 11px;
            color: var(--green);
            font-size: 25px;
            font-weight: 700;
            letter-spacing: -1px;
        }

        .logo-icon {
            display: grid;
            place-items: center;
            width: 42px;
            height: 42px;
            background: var(--green);
            color: white;
            border-radius: 13px;
            font-size: 19px;
        }

        .nav-links {
            display: flex;
            gap: 32px;
            align-items: center;
            font-size: 14px;
            color: #656b64;
        }

        .nav-links a:hover {
            color: var(--green);
        }

        .cart-button {
            border: none;
            background: var(--green);
            color: white;
            border-radius: 12px;
            padding: 12px 18px;
            cursor: pointer;
            font-weight: 600;
        }

        .hero {
            margin: 34px auto 65px;
            width: 86%;
            min-height: 390px;
            border-radius: 28px;
            overflow: hidden;
            display: grid;
            grid-template-columns: 1.05fr 0.95fr;
            background: #e9eee5;
        }

        .hero-content {
            padding: 58px 0 48px 55px;
            align-self: center;
        }

        .eyebrow {
            display: inline-block;
            color: var(--green);
            background: #d9e5d9;
            padding: 9px 14px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .hero h1 {
            margin: 22px 0 17px;
            font-family: 'Playfair Display', serif;
            font-size: clamp(38px, 4.5vw, 58px);
            line-height: 1.13;
            letter-spacing: -1.5px;
        }

        .hero h1 span {
            color: var(--green);
        }

        .hero p {
            color: #687168;
            line-height: 1.8;
            max-width: 410px;
            font-size: 14px;
        }

        .hero-button {
            display: inline-block;
            margin-top: 27px;
            padding: 15px 23px;
            background: var(--green);
            color: white;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
        }

        .hero-image {
            min-height: 390px;
            background:
                linear-gradient(90deg, rgba(233,238,229,.08), transparent),
                url('https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=1100&q=85')
                center / cover;
        }

        .section {
            width: 86%;
            margin: 0 auto 70px;
        }

        .section-heading {
            display: flex;
            justify-content: space-between;
            align-items: end;
            gap: 20px;
            margin-bottom: 25px;
        }

        .section-heading small {
            color: var(--orange);
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .section-heading h2 {
            font-family: 'Playfair Display', serif;
            font-size: 32px;
            margin-top: 8px;
        }

        .section-heading p {
            color: var(--muted);
            font-size: 13px;
            margin-top: 8px;
        }

                .categories {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 30px;
        }

        .category {
            padding: 12px 20px;
            border: 1px solid #e5e3da;
            border-radius: 30px;
            background: white;
            cursor: pointer;
            color: #62675f;
            transition: .2s;
        }

        .category.active,
        .category:hover {
            background: var(--green);
            color: white;
            border-color: var(--green);
        }

        .menu-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 22px;
        }

        .menu-card {
            background: white;
            border: 1px solid #eeece5;
            border-radius: 19px;
            overflow: hidden;
            transition: transform .2s, box-shadow .2s;
        }

        .menu-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 14px 30px #253d2710;
        }

        .menu-image {
            height: 180px;
            position: relative;
            background: #eae7df;
        }

        .menu-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .menu-label {
            position: absolute;
            top: 12px;
            left: 12px;
            padding: 7px 10px;
            background: white;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 700;
        }

        .menu-info {
            padding: 18px;
        }

        .menu-info h3 {
            font-size: 16px;
            margin-bottom: 7px;
        }

        .menu-description {
            font-size: 12px;
            line-height: 1.6;
            color: var(--muted);
            min-height: 38px;
        }

        .menu-bottom {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            margin-top: 18px;
        }

        .price {
            font-size: 15px;
            color: var(--green);
            font-weight: 700;
        }

        .add-button {
            border: none;
            background: var(--green-light);
            color: var(--green);
            width: 37px;
            height: 37px;
            border-radius: 11px;
            font-size: 23px;
            cursor: pointer;
        }

        .add-button:hover {
            background: var(--green);
            color: white;
        }

        .empty-message {
            display: none;
            color: var(--muted);
            padding: 30px 0;
        }

        .footer {
            padding: 32px 7%;
            background: var(--green);
            color: white;
            display: flex;
            justify-content: space-between;
            gap: 20px;
            font-size: 13px;
        }

        .cart-notice {
            position: fixed;
            right: 24px;
            bottom: 24px;
            background: var(--green);
            color: white;
            padding: 16px 22px;
            border-radius: 14px;
            box-shadow: 0 8px 30px #0002;
            display: none;
            z-index: 10;
        }

        @media (max-width: 950px) {
            .menu-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .hero {
                grid-template-columns: 1fr 0.8fr;
            }

            .hero-content {
                padding: 35px;
            }

            .nav-links {
                gap: 15px;
            }
        }

        @media (max-width: 600px) {
            .navbar {
                height: 68px;
                padding: 0 5%;
            }

            .logo {
                font-size: 21px;
            }

            .nav-links a {
                display: none;
            }

            .cart-button {
                padding: 10px 12px;
                font-size: 12px;
            }

            .hero {
                width: 90%;
                margin: 20px auto 45px;
                grid-template-columns: 1fr;
            }

            .hero-content {
                padding: 35px 25px;
            }

            .hero-image {
                min-height: 220px;
                grid-row: 1;
            }

            .hero h1 {
                font-size: 39px;
            }

            .section {
                width: 90%;
            }

            .section-heading h2 {
                font-size: 27px;
            }

            .menu-grid {
                gap: 12px;
            }

            .menu-image {
                height: 135px;
            }

            .menu-info {
                padding: 12px;
            }

            .menu-info h3 {
                font-size: 14px;
            }

            .menu-description {
                font-size: 11px;
            }

            .price {
                font-size: 12px;
            }

            .footer {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<header class="navbar">
    <a href="/" class="logo">
        <span class="logo-icon">R</span>
        QResto
    </a>

    <nav class="nav-links">
        <a href="#beranda">Beranda</a>
        <a href="#menu">Menu</a>
        <a href="#tentang">Tentang</a>
    </nav>

    <button class="cart-button" onclick="lihatKeranjang()">
        🛒 Keranjang (<span id="cart-count">0</span>)
    </button>
</header>

<main>
    <section class="hero" id="beranda">
        <div class="hero-content">
            <span class="eyebrow">Fresh food, happy mood</span>

            <h1>Nikmati Rasa,<br><span>Ciptakan Cerita.</span></h1>

            <p>
                Sajian lezat, bahan berkualitas, dan pengalaman makan
                yang menyenangkan. Temukan menu favoritmu hari ini.
            </p>

            <a href="#menu" class="hero-button">Jelajahi Menu &nbsp; →</a>
        </div>

        <div class="hero-image" role="img" aria-label="Hidangan segar"></div>
    </section>

    <section class="section" id="menu">
        <div class="section-heading">
            <div>
                <small>Our selection</small>
                <h2>Menu Favorit</h2>
                <p>Pilih hidangan favoritmu dan pesan dengan mudah.</p>
            </div>
        </div>

        <div class="categories">
            <button class="category active" data-category="Semua">Semua Menu</button>
            <button class="category" data-category="Makanan">Makanan</button>
            <button class="category" data-category="Minuman">Minuman</button>
            <button class="category" data-category="Camilan">Camilan</button>
        </div>

        <div class="menu-grid" id="menu-grid">

            <article class="menu-card" data-category="Makanan">
                <div class="menu-image">
                    <img src="https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=700&q=80" alt="Nasi goreng">
                    <span class="menu-label">Favorit</span>
                </div>
                <div class="menu-info">
                    <h3>Nasi Goreng Spesial</h3>
                    <p class="menu-description">Nasi goreng gurih dengan telur dan pelengkap pilihan.</p>
                    <div class="menu-bottom">
                        <span class="price">Rp25.000</span>
                        <button class="add-button" data-name="Nasi Goreng Spesial" data-price="25000">+</button>
                    </div>
                </div>
            </article>

            <article class="menu-card" data-category="Makanan">
                <div class="menu-image">
                    <img src="https://images.unsplash.com/photo-1568901346375-23c9450c58bd?auto=format&fit=crop&w=700&q=80" alt="Burger">
                    <span class="menu-label">Best seller</span>
                </div>
                <div class="menu-info">
                    <h3>Classic Beef Burger</h3>
                    <p class="menu-description">Burger dengan daging sapi, sayuran, dan saus spesial.</p>
                    <div class="menu-bottom">
                        <span class="price">Rp32.000</span>
                        <button class="add-button" data-name="Classic Beef Burger" data-price="32000">+</button>
                    </div>
                </div>
            </article>

            <article class="menu-card" data-category="Makanan">
                <div class="menu-image">
                    <img src="https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=700&q=80" alt="Pizza">
                </div>
                <div class="menu-info">
                    <h3>Pizza Special</h3>
                    <p class="menu-description">Pizza dengan topping melimpah dan keju pilihan.</p>
                    <div class="menu-bottom">
                        <span class="price">Rp45.000</span>
                        <button class="add-button" data-name="Pizza Special" data-price="45000">+</button>
                    </div>
                </div>
            </article>

            <article class="menu-card" data-category="Minuman">
                <div class="menu-image">
                    <img src="https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=700&q=80" alt="Kopi susu">
                </div>
                <div class="menu-info">
                    <h3>Es Kopi Susu</h3>
                    <p class="menu-description">Perpaduan kopi, susu, dan es yang menyegarkan.</p>
                    <div class="menu-bottom">
                        <span class="price">Rp18.000</span>
                        <button class="add-button" data-name="Es Kopi Susu" data-price="18000">+</button>
                    </div>
                </div>
            </article>

            <article class="menu-card" data-category="Minuman">
                <div class="menu-image">
                    <img src="https://images.unsplash.com/photo-1513558161293-cdaf765edfd7?auto=format&fit=crop&w=700&q=80" alt="Lemon tea">
                </div>
                <div class="menu-info">
                    <h3>Lemon Tea</h3>
                    <p class="menu-description">Teh dengan lemon segar untuk menemani hidanganmu.</p>
                    <div class="menu-bottom">
                        <span class="price">Rp12.000</span>
                        <button class="add-button" data-name="Lemon Tea" data-price="12000">+</button>
                    </div>
                </div>
            </article>

            <article class="menu-card" data-category="Camilan">
                <div class="menu-image">
                    <img src="https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=700&q=80" alt="Kentang goreng">
                </div>
                <div class="menu-info">
                    <h3>French Fries</h3>
                    <p class="menu-description">Kentang goreng renyah dengan bumbu pilihan.</p>
                    <div class="menu-bottom">
                        <span class="price">Rp15.000</span>
                        <button class="add-button" data-name="French Fries" data-price="15000">+</button>
                    </div>
                </div>
            </article>

            <article class="menu-card" data-category="Camilan">
                <div class="menu-image">
                    <img src="https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=700&q=80" alt="Es krim">
                </div>
                <div class="menu-info">
                    <h3>Ice Cream</h3>
                    <p class="menu-description">Es krim lembut sebagai penutup hidangan.</p>
                    <div class="menu-bottom">
                        <span class="price">Rp13.000</span>
                        <button class="add-button" data-name="Ice Cream" data-price="13000">+</button>
                    </div>
                </div>
            </article>

            <article class="menu-card" data-category="Makanan">
                <div class="menu-image">
                    <img src="https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=700&q=80" alt="Salad">
                </div>
                <div class="menu-info">
                    <h3>Fresh Salad</h3>
                    <p class="menu-description">Sayuran segar dengan dressing yang lezat.</p>
                    <div class="menu-bottom">
                        <span class="price">Rp22.000</span>
                        <button class="add-button" data-name="Fresh Salad" data-price="22000">+</button>
                    </div>
                </div>
            </article>

        </div>

        <p class="empty-message" id="empty-message">Belum ada menu dalam kategori ini.</p>
    </section>
</main>

<footer class="footer" id="tentang">
    <div>
        <strong>QResto</strong>
        <p style="margin-top: 8px;">Sajian istimewa, pengalaman berkesan.</p>
    </div>
    <p>© <?php echo e(date('Y')); ?> QResto. All rights reserved.</p>
</footer>

<div class="cart-notice" id="cart-notice"></div>

<script>
    let cart = [];

    function formatRupiah(number) {
        return 'Rp' + number.toLocaleString('id-ID');
    }

    function updateCartCount() {
        const total = cart.reduce((sum, item) => sum + item.qty, 0);
        document.getElementById('cart-count').textContent = total;
    }

    document.querySelectorAll('.add-button').forEach(button => {
        button.addEventListener('click', () => {
            const name = button.dataset.name;
            const price = Number(button.dataset.price);

            const existing = cart.find(item => item.name === name);

            if (existing) {
                existing.qty++;
            } else {
                cart.push({ name, price, qty: 1 });
            }

            updateCartCount();
            showNotice(name + ' ditambahkan ke keranjang');
        });
    });

    function showNotice(message) {
        const notice = document.getElementById('cart-notice');
        notice.textContent = message;
        notice.style.display = 'block';

        clearTimeout(window.noticeTimer);

        window.noticeTimer = setTimeout(() => {
            notice.style.display = 'none';
        }, 2200);
    }

    function lihatKeranjang() {
        if (cart.length === 0) {
            alert('Keranjang masih kosong. Silakan pilih menu terlebih dahulu.');
            return;
        }

        const detail = cart.map(item =>
            item.name + ' x' + item.qty + ' = ' +
            formatRupiah(item.price * item.qty)
        );

        const total = cart.reduce(
            (sum, item) => sum + item.price * item.qty, 0
        );

        alert(
            'KERANJANG QResto\n\n' +
            detail.join('\n') +
            '\n\nTotal: ' + formatRupiah(total) +
            '\n\nCheckout akan dibuat pada tahap berikutnya.'
        );
    }

    document.querySelectorAll('.category').forEach(button => {
        button.addEventListener('click', () => {
            document.querySelectorAll('.category').forEach(item => {
                item.classList.remove('active');
            });

            button.classList.add('active');

            const category = button.dataset.category;
            let visibleCount = 0;

            document.querySelectorAll('.menu-card').forEach(card => {
                const show = category === 'Semua' ||
                    card.dataset.category === category;

                card.style.display = show ? '' : 'none';

                if (show) visibleCount++;
            });

            document.getElementById('empty-message').style.display =
                visibleCount === 0 ? 'block' : 'none';
        });
    });
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\QResto\resources\views/customer/home.blade.php ENDPATH**/ ?>