<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>QResto</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
</head>

  <style>
    <#cssawal

    {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: Arial, sans-serif;
    }

    body {
        min-height: 100vh;
        background: #f5f5f5;
        display: flex;
        justify-content: center;
    }

    .app {
        width: 100%;
        max-width: 430px;
        min-height: 100vh;
        background: white;
    }
   
     /* D. CSS HALAMAN WELCOME */

.welcome {
    min-height: 100vh;
    padding: 35px 25px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
}

.logo {
    font-size: 28px;
    font-weight: bold;
}

.tagline {
    margin-top: 8px;
    color: #888;
    font-size: 14px;
}

.food-icon {
    width: 150px;
    height: 150px;
    margin: 45px 0 30px;

    border-radius: 50%;
    background: #fff1e5;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 75px;
}

.welcome h1 {
    font-size: 30px;
    margin-bottom: 12px;
}

.description {
    max-width: 300px;
    color: #777;
    font-size: 15px;
    line-height: 1.6;
}

.table-info {
    margin-top: 25px;
    padding: 12px 24px;

    border-radius: 30px;
    background: #f5f5f5;

    font-size: 14px;
    font-weight: bold;
}

.start-button {
    width: 100%;
    max-width: 350px;

    margin-top: 25px;
    padding: 16px;

    border: none;
    border-radius: 14px;

    background: #ff7a00;
    color: white;

    font-size: 16px;
    font-weight: bold;

    cursor: pointer;
    transition: 0.2s;
}

.start-button:hover {
    transform: translateY(-2px);
}

.footer {
    margin-top: 25px;
    color: #aaa;
    font-size: 12px;
}

/* G. CSS HALAMAN PILIH PESANAN */

.order-page {
    display: none;
    min-height: 100vh;
    background: white;
}

.order-header {
    padding: 25px;
    display: flex;
    align-items: center;
    gap: 15px;
    border-bottom: 1px solid #eeeeee;
}

.back-button {
    width: 42px;
    height: 42px;
    border: none;
    border-radius: 12px;
    background: #f5f5f5;
    font-size: 20px;
    cursor: pointer;
}

.order-logo {
    font-size: 20px;
    font-weight: bold;
}

.order-table {
    margin-top: 4px;
    color: #888;
    font-size: 13px;
}

.order-content {
    padding: 35px 25px;
}

.step {
    color: #ff7a00;
    font-size: 12px;
    font-weight: bold;
    letter-spacing: 1px;
    margin-bottom: 10px;
}

.order-content h1 {
    font-size: 28px;
    margin-bottom: 10px;
}

.order-description {
    color: #777;
    font-size: 15px;
    line-height: 1.5;
    margin-bottom: 30px;
}

.order-options {
    display: flex;
    flex-direction: column;
    gap: 16px;
}

.order-card {
    display: flex;
    align-items: center;
    padding: 20px;
    border: 1px solid #eeeeee;
    border-radius: 18px;
    cursor: pointer;
    transition: 0.2s;
}

.order-card:hover {
    transform: translateY(-3px);
    border-color: #ff7a00;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
}

.order-icon {
    width: 55px;
    height: 55px;
    border-radius: 15px;
    background: #fff1e5;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 28px;
    margin-right: 15px;
}

.order-info {
    flex: 1;
}

.order-info h2 {
    font-size: 18px;
    margin-bottom: 5px;
}

.order-info p {
    color: #888;
    font-size: 13px;
}

.arrow {
    color: #ff7a00;
    font-size: 22px;
}

/* K. CSS HALAMAN MENU */

.menu-page {
    display: none;
    min-height: 100vh;
    background: #ffffff;
}

.menu-header {
    padding: 20px 25px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #eeeeee;
}

.menu-logo {
    font-size: 21px;
    font-weight: bold;
}

.menu-info {
    margin-top: 5px;
    font-size: 13px;
    color: #888888;
}

.cart-button {
    position: relative;
    width: 45px;
    height: 45px;
    border: none;
    border-radius: 13px;
    background: #fff1e5;
    font-size: 20px;
    cursor: pointer;
}
.menu-header .cart-button {
    display: none;
}

.cart-count {
    position: absolute;
    top: -5px;
    right: -5px;

    min-width: 20px;
    height: 20px;

    padding: 2px 5px;
    border-radius: 50%;

    background: #ff7a00;
    color: white;

    font-size: 11px;
    font-weight: bold;

    display: flex;
    align-items: center;
    justify-content: center;
}

.menu-content {
    padding: 25px;
}

.menu-content h1 {
    font-size: 27px;
    margin-bottom: 7px;
}

.menu-subtitle {
    color: #888888;
    font-size: 14px;
    margin-bottom: 22px;
}

.search-box {
    height: 48px;
    padding: 0 15px;

    display: flex;
    align-items: center;
    gap: 10px;

    background: #f6f6f6;
    border-radius: 14px;

    margin-bottom: 20px;
}

.search-box span {
    font-size: 17px;
}

.search-box input {
    width: 100%;
    border: none;
    outline: none;
    background: transparent;
    font-size: 14px;
}

.categories {
    display: flex;
    gap: 10px;
    overflow-x: auto;
    padding-bottom: 5px;
    margin-bottom: 25px;
}

.category {
    flex-shrink: 0;

    padding: 10px 17px;

    border: 1px solid #eeeeee;
    border-radius: 25px;

    background: white;
    color: #555555;

    cursor: pointer;
}

.category.active {
    background: #ff7a00;
    border-color: #ff7a00;
    color: white;
}

.section-title {
    font-size: 20px;
    margin-bottom: 17px;
}

.food-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.food-card {
    display: flex;
    padding: 13px;

    border: 1px solid #eeeeee;
    border-radius: 18px;

    background: white;

    transition: 0.2s;
}

.food-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 7px 20px rgba(0, 0, 0, 0.07);
}

.food-image {
    width: 105px;
    height: 105px;

    flex-shrink: 0;

    border-radius: 15px;
    background: #fff1e5;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 48px;
}

.food-detail {
    padding: 5px 0 5px 15px;
    flex: 1;
}

.food-detail h3 {
    font-size: 17px;
    margin-bottom: 6px;
}

.food-detail p {
    color: #888888;
    font-size: 12px;
    line-height: 1.4;
}

.food-bottom {
    margin-top: 13px;

    display: flex;
    align-items: center;
    justify-content: space-between;
}

.food-bottom strong {
    font-size: 15px;
}

.add-button {
    width: 34px;
    height: 34px;

    border: none;
    border-radius: 10px;

    background: #ff7a00;
    color: white;

    font-size: 22px;
    cursor: pointer;
}

/* N. CSS HALAMAN DETAIL MENU */

.detail-page {
    min-height: 100vh;
    background: #ffffff;
}

.detail-header {
    position: sticky;
    top: 0;
    z-index: 10;

    height: 65px;
    padding: 0 20px;

    display: flex;
    align-items: center;
    justify-content: space-between;

    background: rgba(255, 255, 255, 0.96);
    border-bottom: 1px solid #eeeeee;
}

.detail-header h2 {
    margin: 0;
    font-size: 18px;
}

.detail-header-space {
    width: 42px;
}

.detail-back {
    width: 42px;
    height: 42px;

    border: none;
    border-radius: 12px;

    background: #f5f5f5;
    font-size: 22px;

    cursor: pointer;
}

.detail-back:hover {
    background: #eeeeee;
}

.detail-content {
    padding: 20px;
    padding-bottom: 35px;
}

.detail-image {
    width: 100%;
    height: 240px;

    display: flex;
    align-items: center;
    justify-content: center;

    background: #fff1e5;
    border-radius: 24px;

    font-size: 95px;

    margin-bottom: 22px;
}

.detail-category {
    margin: 0 0 6px;

    font-size: 11px;
    font-weight: bold;

    color: #ff7a00;
    letter-spacing: 1px;
}

.detail-name {
    margin: 0 0 5px;

    font-size: 28px;
    font-weight: 700;
}

.detail-price {
    margin: 0 0 12px;

    font-size: 20px;
    color: #ff7a00;
}

.detail-description {
    margin: 0;

    color: #777777;
    font-size: 14px;
    line-height: 1.6;
}

.detail-section {
    margin-top: 25px;
}

.detail-section h3,
.quantity-section h3 {
    margin: 0 0 5px;

    font-size: 16px;
}

.detail-small {
    margin: 0 0 12px;

    color: #999999;
    font-size: 12px;
}

/* LEVEL PEDAS */

.level-options {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.level-button {
    padding: 10px 14px;

    border: 1px solid #eeeeee;
    border-radius: 12px;

    background: #ffffff;
    color: #555555;

    font-size: 13px;
    cursor: pointer;
}

.level-button:hover {
    border-color: #ff7a00;
}

.level-button.active {
    background: #fff1e5;
    border-color: #ff7a00;
    color: #ff7a00;
    font-weight: bold;
}

/* CATATAN */

.order-note {
    width: 100%;
    min-height: 95px;

    box-sizing: border-box;

    padding: 13px;

    border: 1px solid #eeeeee;
    border-radius: 14px;

    background: #ffffff;

    font-family: inherit;
    font-size: 14px;

    resize: none;
    outline: none;
}

.order-note:focus {
    border-color: #ff7a00;
}

/* JUMLAH */

.quantity-section {
    margin-top: 25px;

    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 15px;
}

.quantity-control {
    display: flex;
    align-items: center;
    gap: 12px;

    padding: 6px;

    background: #f5f5f5;
    border-radius: 14px;
}

.quantity-minus,
.quantity-plus {
    width: 34px;
    height: 34px;

    border: none;
    border-radius: 10px;

    background: #ffffff;

    font-size: 20px;
    cursor: pointer;
}

.quantity-minus:hover,
.quantity-plus:hover {
    background: #eeeeee;
}

.quantity-number {
    min-width: 20px;

    text-align: center;

    font-size: 15px;
    font-weight: bold;
}
/* TOMBOL TAMBAH KE KERANJANG */

.detail-cart-row {
    display: flex;
    gap: 10px;
    align-items: stretch;
    margin-top: 28px;
}

.add-cart-detail {
    flex: 1;
    padding: 16px 18px;

    display: flex;
    align-items: center;
    justify-content: space-between;

    border: none;
    border-radius: 15px;

    background: #ff7a00;
    color: #ffffff;

    font-size: 15px;
    font-weight: bold;

    cursor: pointer;

    box-shadow: 0 8px 20px rgba(255, 122, 0, 0.20);
}

.detail-cart-button {
    position: relative;

    width: 58px;
    flex-shrink: 0;

    border: none;
    border-radius: 15px;

    background: #fff1e5;

    font-size: 22px;
    cursor: pointer;
}

.detail-cart-count {
    position: absolute;
    top: -6px;
    right: -5px;

    min-width: 20px;
    height: 20px;

    padding: 2px 5px;
    border-radius: 50%;

    background: #ff7a00;
    color: white;

    font-size: 11px;
    font-weight: bold;

    display: flex;
    align-items: center;
    justify-content: center;
}

.add-cart-detail strong {
    font-size: 14px;
}

.add-cart-detail:hover {
    transform: translateY(-1px);
}

.mini-cart {
    position: fixed;
    left: 50%;
    bottom: 15px;
    transform: translateX(-50%);

    width: calc(100% - 30px);
    max-width: 400px;

    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;

    padding: 12px 14px;

    background: #ffffff;
    border: 1px solid #eeeeee;
    border-radius: 16px;

    box-shadow: 0 8px 25px rgba(0,0,0,0.12);

    z-index: 50;
    display: none;
}

.mini-cart-info {
    display: flex;
    align-items: center;
    gap: 10px;
}

.mini-cart-icon {
    font-size: 25px;
}

.mini-cart-info strong {
    font-size: 13px;
}

.mini-cart-total {
    margin: 3px 0 0;
    color: #ff7a00;
    font-size: 12px;
    font-weight: bold;
}

.mini-cart-button {
    padding: 11px 13px;

    border: none;
    border-radius: 11px;

    background: #ff7a00;
    color: #ffffff;

    font-size: 12px;
    font-weight: bold;
    cursor: pointer;
}

/* KERANJANG BAWAH MENU */

.menu-cart-bar {
    position: fixed;
    left: 50%;
    bottom: 12px;
    transform: translateX(-50%);

    width: calc(100% - 24px);
    max-width: 406px;

    display: none;
    align-items: center;
    gap: 10px;

    padding: 10px;

    background: #ffffff;
    border: 1px solid #eeeeee;
    border-radius: 18px;

    box-shadow: 0 8px 25px rgba(0,0,0,0.15);

    z-index: 100;
}

.menu-cart-info {
    flex: 1;
    min-width: 0;

    display: flex;
    flex-direction: column;
    gap: 3px;
}

.menu-cart-count {
    font-size: 13px;
}

.menu-cart-total {
    color: #ff7a00;
    font-size: 14px;
    font-weight: bold;
}

.menu-add-more {
    padding: 11px 12px;

    border: 1px solid #ff7a00;
    border-radius: 12px;

    background: #fff1e5;
    color: #ff7a00;

    font-size: 11px;
    font-weight: bold;

    cursor: pointer;
}

.menu-cart-open {
    position: relative;

    width: 48px;
    height: 48px;
    flex-shrink: 0;

    border: none;
    border-radius: 14px;

    background: #ff7a00;
    color: white;

    font-size: 21px;

    cursor: pointer;
}

.menu-cart-badge {
    position: absolute;
    top: -5px;
    right: -5px;

    min-width: 19px;
    height: 19px;

    padding: 2px 5px;

    border-radius: 50%;

    background: #ffffff;
    color: #ff7a00;

    font-size: 10px;
    font-weight: bold;

    display: flex;
    align-items: center;
    justify-content: center;
}

/* R. CSS HALAMAN KERANJANG */

.cart-page {
    min-height: 100vh;
    background: #ffffff;
}

.cart-header {
    position: sticky;
    top: 0;
    z-index: 10;

    height: 65px;
    padding: 0 20px;

    display: flex;
    align-items: center;
    justify-content: space-between;

    background: rgba(255, 255, 255, 0.96);
    border-bottom: 1px solid #eeeeee;
}

.cart-header h2 {
    margin: 0;
    font-size: 18px;
}

.cart-header-space {
    width: 42px;
}

.cart-back {
    width: 42px;
    height: 42px;

    border: none;
    border-radius: 12px;

    background: #f5f5f5;
    font-size: 22px;
    cursor: pointer;
}

.cart-content {
    padding: 20px;
    padding-bottom: 35px;
}
.cart-subtitle {
    margin-bottom: 15px;
    color: #888888;
    font-size: 13px;
}

/* ITEM KERANJANG */

.cart-item {
    display: flex;
    align-items: center;
    gap: 12px;

    padding: 14px;

    background: #ffffff;
    border: 1px solid #eeeeee;
    border-radius: 18px;

    margin-bottom: 12px;
}

.cart-item-image {
    width: 60px;
    height: 60px;

    flex-shrink: 0;

    display: flex;
    align-items: center;
    justify-content: center;

    background: #fff1e5;
    border-radius: 14px;

    font-size: 30px;
}

.cart-item-info {
    flex: 1;
    min-width: 0;
}

.cart-item-name {
    margin: 0 0 5px;

    font-size: 15px;
}

.cart-item-detail {
    margin: 0 0 5px;

    color: #999999;
    font-size: 12px;
}

.cart-item-price {
    color: #ff7a00;
    font-size: 13px;
}

/* JUMLAH ITEM */

.cart-item-quantity {
    display: flex;
    align-items: center;
    gap: 7px;

    padding: 4px;

    background: #f5f5f5;
    border-radius: 10px;
}

.cart-minus,
.cart-plus {
    width: 28px;
    height: 28px;

    border: none;
    border-radius: 8px;

    background: #ffffff;

    font-size: 17px;
    cursor: pointer;
}

.cart-item-quantity span {
    min-width: 18px;

    text-align: center;

    font-size: 13px;
    font-weight: bold;
}

/* KERANJANG KOSONG */

.cart-empty {
    text-align: center;
    padding: 70px 20px;
}

.cart-empty-icon {
    font-size: 65px;
    margin-bottom: 15px;
}

.cart-empty h3 {
    margin: 0 0 8px;
    font-size: 18px;
}

.cart-empty p {
    margin: 0;

    color: #999999;
    font-size: 13px;
    line-height: 1.5;
}

/* RINGKASAN */

.cart-summary {
    margin-top: 25px;
    padding: 18px;

    background: #f8f8f8;
    border-radius: 16px;
}

.summary-row {
    display: flex;
    justify-content: space-between;
    align-items: center;

    margin-bottom: 12px;

    font-size: 14px;
}

.summary-row:last-child {
    margin-bottom: 0;
    padding-top: 12px;

    border-top: 1px solid #dddddd;

    font-size: 17px;
}

.summary-row strong {
    color: #ff7a00;
}

/* CHECKOUT */
.add-more-menu-button {
    width: 100%;
    margin-top: 18px;
    padding: 14px;
    border: 1px solid #ff7a00;
    border-radius: 15px;
    background: #fff1e5;
    color: #ff7a00;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
}

.checkout-button {
    width: 100%;

    margin-top: 18px;
    padding: 16px;

    border: none;
    border-radius: 15px;

    background: #ff7a00;
    color: #ffffff;

    font-size: 15px;
    font-weight: bold;

    cursor: pointer;

    box-shadow: 0 8px 20px rgba(255, 122, 0, 0.20);
}

.checkout-button:hover {
    transform: translateY(-1px);
}

/* U. CSS HALAMAN PEMBAYARAN */

.payment-page {
    min-height: 100vh;
    background: #ffffff;
}

.payment-header {
    position: sticky;
    top: 0;
    z-index: 10;

    height: 65px;
    padding: 0 20px;

    display: flex;
    align-items: center;
    justify-content: space-between;

    background: rgba(255, 255, 255, 0.96);
    border-bottom: 1px solid #eeeeee;
}

.payment-header h2 {
    margin: 0;
    font-size: 18px;
}

.payment-header-space {
    width: 42px;
}

.payment-back {
    width: 42px;
    height: 42px;

    border: none;
    border-radius: 12px;

    background: #f5f5f5;

    font-size: 22px;
    cursor: pointer;
}

.payment-content {
    padding: 20px;
    padding-bottom: 35px;
}

/* CARD PEMBAYARAN */

.payment-card {
    margin-bottom: 18px;
    padding: 18px;

    border: 1px solid #eeeeee;
    border-radius: 18px;

    background: #ffffff;
}

.payment-card h3 {
    margin: 0 0 6px;
    font-size: 16px;
}

.payment-summary {
    display: flex;
    align-items: center;
    justify-content: space-between;

    margin-top: 15px;
    padding-top: 15px;

    border-top: 1px solid #eeeeee;

    font-size: 14px;
}

.payment-summary strong {
    color: #ff7a00;
    font-size: 18px;
}

.payment-small {
    margin: 0 0 15px;

    color: #999999;
    font-size: 12px;
}

/* METODE PEMBAYARAN */

.payment-methods {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.payment-method {
    width: 100%;

    display: flex;
    align-items: center;
    gap: 13px;

    padding: 14px;

    border: 1px solid #eeeeee;
    border-radius: 14px;

    background: #ffffff;

    text-align: left;
    cursor: pointer;
}

.payment-method:hover {
    border-color: #ff7a00;
}

.payment-method.active {
    border: 2px solid #ff7a00;
    background: #fff8f2;
}

.payment-icon {
    width: 42px;
    height: 42px;

    flex-shrink: 0;

    display: flex;
    align-items: center;
    justify-content: center;

    background: #fff1e5;
    border-radius: 12px;

    font-size: 21px;
}

.payment-method strong {
    display: block;

    margin-bottom: 4px;

    color: #333333;
    font-size: 14px;
}

.payment-method small {
    display: block;

    color: #999999;
    font-size: 11px;
}

/* INFO PEMBAYARAN */

.payment-info {
    display: flex;
    align-items: flex-start;
    gap: 10px;

    padding: 14px;

    background: #f8f8f8;
    border-radius: 14px;
}

.payment-info-icon {
    font-size: 18px;
}

.payment-info p {
    margin: 0;

    color: #777777;
    font-size: 12px;
    line-height: 1.5;
}

/* TOMBOL BAYAR */

.pay-button {
    width: 100%;

    margin-top: 18px;
    padding: 16px;

    border: none;
    border-radius: 15px;

    background: #ff7a00;
    color: #ffffff;

    font-size: 15px;
    font-weight: bold;

    cursor: pointer;

    box-shadow: 0 8px 20px rgba(255, 122, 0, 0.20);
}

.pay-button:hover {
    transform: translateY(-1px);
}

/* X. CSS HALAMAN PESANAN BERHASIL */

.success-page {
    min-height: 100vh;
    background: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 25px;
    box-sizing: border-box;
}

.success-content {
    width: 100%;
    max-width: 420px;
    text-align: center;
}

.success-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 22px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: #e9f8ef;
    color: #28a745;
    font-size: 42px;
    font-weight: bold;
}

.success-content h1 {
    margin: 0 0 10px;
    font-size: 26px;
}

.success-message {
    margin: 0;
    color: #777777;
    font-size: 14px;
    line-height: 1.5;
}

.order-number {
    margin-top: 25px;
    padding: 16px;
    background: #f8f8f8;
    border-radius: 16px;
}

.order-number span {
    display: block;
    margin-bottom: 6px;
    color: #999999;
    font-size: 12px;
}

.order-number strong {
    font-size: 18px;
}

.order-qr {
    margin-top: 12px;
    padding: 16px;
    background: #f8f8f8;
    border-radius: 16px;
    text-align: center;
}

.order-qr p {
    margin: 0 0 12px;
    color: #777777;
    font-size: 13px;
}

#qrPesanan {
    display: flex;
    justify-content: center;
}

.success-info {
    margin-top: 12px;
    padding: 16px;
    border: 1px solid #eeeeee;
    border-radius: 16px;
    text-align: left;
}

.success-info div {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 7px 0;
    font-size: 13px;
}

.success-info span {
    color: #888888;
}

.success-info strong {
    color: #333333;
}

.track-order-button,
.back-menu-button {
    width: 100%;
    padding: 15px;
    border-radius: 14px;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
}

.track-order-button {
    margin-top: 22px;
    border: none;
    background: #ff7a00;
    color: #ffffff;
}

.back-menu-button {
    margin-top: 10px;
    border: 1px solid #eeeeee;
    background: #ffffff;
    color: #555555;
}

.track-order-button:hover,
.back-menu-button:hover {
    transform: translateY(-1px);
}

/* Z2. CSS FITUR DINE IN */

.dinein-page {
    min-height: 100vh;
    background: #ffffff;
}

.dinein-header {
    position: sticky;
    top: 0;
    z-index: 10;
    height: 65px;
    padding: 0 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: rgba(255, 255, 255, 0.96);
    border-bottom: 1px solid #eeeeee;
}

.dinein-header h2 {
    margin: 0;
    font-size: 18px;
}

.dinein-header-space {
    width: 42px;
}

.dinein-back {
    width: 42px;
    height: 42px;
    border: none;
    border-radius: 12px;
    background: #f5f5f5;
    font-size: 22px;
    cursor: pointer;
}

.dinein-content {
    padding: 20px;
    padding-bottom: 35px;
}

.table-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px;
    margin-bottom: 18px;
    background: #fff1e5;
    border-radius: 16px;
}

.table-info span {
    color: #777777;
    font-size: 13px;
}

.table-info strong {
    color: #ff7a00;
    font-size: 15px;
}

.dinein-card {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 16px;
    margin-bottom: 12px;
    border: 1px solid #eeeeee;
    border-radius: 18px;
    background: #ffffff;
}

.dinein-icon {
    width: 45px;
    height: 45px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fff1e5;
    border-radius: 13px;
    font-size: 21px;
}

.dinein-card h3 {
    margin: 0 0 5px;
    font-size: 15px;
}

.dinein-card p {
    margin: 0;
    color: #999999;
    font-size: 12px;
    line-height: 1.5;
}

.call-waiter-button,
.request-bill-button {
    margin-left: auto;
    padding: 9px 13px;
    border: none;
    border-radius: 10px;
    background: #ff7a00;
    color: #ffffff;
    font-size: 12px;
    font-weight: bold;
    cursor: pointer;
}

.call-waiter-button:hover,
.request-bill-button:hover {
    transform: translateY(-1px);
}

.rating-card {
    align-items: flex-start;
}

.rating-content {
    flex: 1;
}

.rating-stars {
    display: flex;
    gap: 5px;
    margin-top: 12px;
}

.rating-stars button {
    padding: 0;
    border: none;
    background: transparent;
    color: #cccccc;
    font-size: 27px;
    cursor: pointer;
}

.rating-stars button.active {
    color: #ffb000;
}

.rating-note {
    width: 100%;
    min-height: 80px;
    margin-top: 12px;
    padding: 12px;
    box-sizing: border-box;
    border: 1px solid #eeeeee;
    border-radius: 12px;
    background: #ffffff;
    font-family: inherit;
    font-size: 13px;
    resize: none;
    outline: none;
}

.rating-note:focus {
    border-color: #ff7a00;
}

.submit-rating-button {
    width: 100%;
    margin-top: 10px;
    padding: 12px;
    border: none;
    border-radius: 12px;
    background: #ff7a00;
    color: #ffffff;
    font-size: 13px;
    font-weight: bold;
    cursor: pointer;
}

.submit-rating-button:hover {
    transform: translateY(-1px);
}

/* AA2. CSS ADMIN DASHBOARD */

.admin-page {
    width: 100vw;
    min-height: 100vh;
    margin-left: calc(50% - 50vw);
    background: #f7f7f7;
}

.admin-header {
    padding: 22px 25px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: #ffffff;
    border-bottom: 1px solid #eeeeee;
}
.admin-header > * {
    max-width: 1100px;
}

.admin-label {
    margin: 0 0 4px;
    color: #ff7a00;
    font-size: 11px;
    font-weight: bold;
    letter-spacing: 1px;
}

.admin-header h2 {
    margin: 0;
    font-size: 22px;
}

.admin-menu-button {
    width: 42px;
    height: 42px;
    border: none;
    border-radius: 12px;
    background: #f5f5f5;
    font-size: 20px;
    cursor: pointer;
}

.admin-content {
    padding: 20px 25px 35px;
    max-width: 1100px;
    margin: 0 auto;
}

.admin-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 14px;
}

.admin-stat-card {
    padding: 18px;
    background: #ffffff;
    border: 1px solid #eeeeee;
    border-radius: 17px;
}

.admin-stat-card > span {
    font-size: 23px;
}

.admin-stat-card p {
    margin: 12px 0 5px;
    color: #888888;
    font-size: 12px;
}

.admin-stat-card strong {
    font-size: 20px;
}

.admin-section {
    margin-top: 25px;
}

.admin-section-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 13px;
}

.admin-section-title h3 {
    margin: 0 0 4px;
    font-size: 17px;
}

.admin-section-title p {
    margin: 0;
    color: #999999;
    font-size: 12px;
}

.admin-menu-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 13px;
}

.admin-menu-card {
    padding: 18px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 7px;
    border: 1px solid #eeeeee;
    border-radius: 17px;
    background: #ffffff;
    text-align: left;
    cursor: pointer;
}

.admin-menu-card:hover {
    border-color: #ff7a00;
    transform: translateY(-2px);
}

.admin-menu-card > span {
    width: 42px;
    height: 42px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fff1e5;
    border-radius: 12px;
    font-size: 20px;
}

.admin-menu-card strong {
    font-size: 14px;
}

.admin-menu-card small {
    color: #999999;
    font-size: 11px;
}

.admin-see-all {
    padding: 8px 12px;
    border: none;
    border-radius: 9px;
    background: #fff1e5;
    color: #ff7a00;
    font-size: 11px;
    font-weight: bold;
    cursor: pointer;
}

.admin-orders {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.admin-order {
    padding: 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    background: #ffffff;
    border: 1px solid #eeeeee;
    border-radius: 16px;
}

.admin-order > div:last-child {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 6px;
}

.admin-order strong {
    font-size: 13px;
}

.admin-order p {
    margin: 5px 0 0;
    color: #999999;
    font-size: 11px;
}

.admin-order span {
    padding: 5px 9px;
    border-radius: 8px;
    font-size: 10px;
    font-weight: bold;
}

.status-processing {
    background: #fff1e5;
    color: #ff7a00;
}

.status-new {
    background: #eaf3ff;
    color: #2878d4;
}

.status-done {
    background: #e9f8ef;
    color: #28a745;
}

/* RESPONSIVE ADMIN */

@media (max-width: 700px) {

    .admin-content {
        padding: 18px 15px 30px;
    }

    .admin-header {
        padding: 18px 15px;
    }

    .admin-stats {
        grid-template-columns: repeat(2, 1fr);
    }

    .admin-menu-grid {
        grid-template-columns: repeat(2, 1fr);
    }

}

@media (max-width: 450px) {

    .admin-stats {
        grid-template-columns: 1fr 1fr;
        gap: 10px;
    }

    .admin-stat-card {
        padding: 14px;
    }

    .admin-menu-grid {
        grid-template-columns: 1fr;
    }

}


/* AB2. CSS KELOLA MENU ADMIN */

.admin-menu-page {
    min-height: 100vh;
    background: #f7f7f7;
}

.admin-menu-page .admin-header {
    position: sticky;
    top: 0;
    z-index: 10;
}

.admin-menu-back {
    width: 42px;
    height: 42px;
    border: none;
    border-radius: 12px;
    background: #f5f5f5;
    font-size: 22px;
    cursor: pointer;
}

.add-menu-button {
    width: 100%;
    padding: 15px;
    border: none;
    border-radius: 14px;
    background: #ff7a00;
    color: #ffffff;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
    box-shadow: 0 7px 18px rgba(255, 122, 0, 0.18);
}

.add-menu-button:hover {
    transform: translateY(-1px);
}

.menu-admin-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-top: 18px;
}

.menu-admin-item {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 15px;
    background: #ffffff;
    border: 1px solid #eeeeee;
    border-radius: 17px;
}

.menu-admin-image {
    width: 58px;
    height: 58px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fff1e5;
    border-radius: 14px;
    font-size: 30px;
}

.menu-admin-info {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.menu-admin-info strong {
    font-size: 15px;
}

.menu-admin-info span {
    color: #999999;
    font-size: 11px;
}

.menu-admin-info b {
    color: #ff7a00;
    font-size: 13px;
}

.menu-admin-actions {
    display: flex;
    gap: 6px;
}

.edit-menu-button,
.delete-menu-button {
    padding: 8px 10px;
    border-radius: 9px;
    font-size: 11px;
    font-weight: bold;
    cursor: pointer;
}

.edit-menu-button {
    border: 1px solid #eeeeee;
    background: #ffffff;
    color: #555555;
}

.delete-menu-button {
    border: none;
    background: #fff0f0;
    color: #e53935;
}

.edit-menu-button:hover {
    border-color: #ff7a00;
    color: #ff7a00;
}

.delete-menu-button:hover {
    background: #ffe5e5;
}

@media (max-width: 500px) {

    .menu-admin-item {
        align-items: flex-start;
    }

    .menu-admin-actions {
        flex-direction: column;
    }

}


/* AC2. CSS MEJA & QR CODE */

.table-page {
    min-height: 100vh;
    background: #f7f7f7;
}

.table-page .admin-header {
    position: sticky;
    top: 0;
    z-index: 10;
}

.table-page-back {
    width: 42px;
    height: 42px;
    border: none;
    border-radius: 12px;
    background: #f5f5f5;
    font-size: 22px;
    cursor: pointer;
}

.add-table-button {
    width: 100%;
    padding: 15px;
    border: none;
    border-radius: 14px;
    background: #ff7a00;
    color: #ffffff;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
    box-shadow: 0 7px 18px rgba(255, 122, 0, 0.18);
}

.add-table-button:hover {
    transform: translateY(-1px);
}

.table-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
    margin-top: 18px;
}

.table-card {
    padding: 16px;
    background: #ffffff;
    border: 1px solid #eeeeee;
    border-radius: 18px;
}

.table-card-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
}

.table-number {
    font-size: 16px;
    font-weight: bold;
}

.table-status {
    padding: 5px 9px;
    border-radius: 8px;
    font-size: 10px;
    font-weight: bold;
}

.table-status.available {
    background: #e9f8ef;
    color: #28a745;
}

.table-status.occupied {
    background: #fff1e5;
    color: #ff7a00;
}

.qr-placeholder {
    height: 170px;
    margin-top: 15px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 8px;
    background: #f8f8f8;
    border-radius: 15px;
}

.qr-symbol {
    width: 90px;
    height: 90px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 4px solid #333333;
    background: #ffffff;
    font-size: 55px;
    line-height: 1;
}

.qr-placeholder span {
    color: #888888;
    font-size: 11px;
}

.table-actions {
    display: flex;
    gap: 8px;
    margin-top: 13px;
}

.show-qr-button,
.delete-table-button {
    flex: 1;
    padding: 10px;
    border-radius: 10px;
    font-size: 11px;
    font-weight: bold;
    cursor: pointer;
}

.show-qr-button {
    border: 1px solid #eeeeee;
    background: #ffffff;
    color: #555555;
}

.delete-table-button {
    border: none;
    background: #fff0f0;
    color: #e53935;
}

.show-qr-button:hover {
    border-color: #ff7a00;
    color: #ff7a00;
}

.delete-table-button:hover {
    background: #ffe5e5;
}

@media (max-width: 600px) {

    .table-grid {
        grid-template-columns: 1fr;
    }

}


/* AD2. CSS STATUS PESANAN ADMIN */

.order-admin-page {
    min-height: 100vh;
    background: #f7f7f7;
}

.order-admin-page .admin-header {
    position: sticky;
    top: 0;
    z-index: 10;
}

.order-admin-back {
    width: 42px;
    height: 42px;
    border: none;
    border-radius: 12px;
    background: #f5f5f5;
    font-size: 22px;
    cursor: pointer;
}

.order-filter {
    display: flex;
    gap: 8px;
    overflow-x: auto;
    padding-bottom: 5px;
}

.order-filter-button {
    flex-shrink: 0;
    padding: 9px 14px;
    border: 1px solid #eeeeee;
    border-radius: 10px;
    background: #ffffff;
    color: #777777;
    font-size: 11px;
    font-weight: bold;
    cursor: pointer;
}

.order-filter-button.active {
    background: #ff7a00;
    border-color: #ff7a00;
    color: #ffffff;
}

.order-admin-list {
    display: flex;
    flex-direction: column;
    gap: 13px;
    margin-top: 18px;
}

.order-admin-card {
    padding: 17px;
    background: #ffffff;
    border: 1px solid #eeeeee;
    border-radius: 17px;
}

.order-admin-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 15px;
}

.order-admin-top strong {
    font-size: 14px;
}

.order-admin-top p {
    margin: 5px 0 0;
    color: #999999;
    font-size: 11px;
}

.order-status {
    padding: 6px 9px;
    border-radius: 8px;
    font-size: 10px;
    font-weight: bold;
}

.order-status.new {
    background: #eaf3ff;
    color: #2878d4;
}

.order-status.processing {
    background: #fff1e5;
    color: #ff7a00;
}

.order-status.done {
    background: #e9f8ef;
    color: #28a745;
}

.order-admin-items {
    margin-top: 15px;
    padding: 12px 0;
    border-top: 1px solid #eeeeee;
    border-bottom: 1px solid #eeeeee;
}

.order-admin-items div {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    padding: 5px 0;
    font-size: 12px;
}

.order-admin-items span {
    color: #666666;
}

.order-admin-items strong {
    font-size: 11px;
}

.order-admin-bottom {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin-top: 13px;
}

.order-admin-bottom > strong {
    font-size: 13px;
}

.change-status-button {
    padding: 9px 12px;
    border: none;
    border-radius: 10px;
    background: #ff7a00;
    color: #ffffff;
    font-size: 11px;
    font-weight: bold;
    cursor: pointer;
}

.change-status-button:hover {
    transform: translateY(-1px);
}

@media (max-width: 450px) {

    .order-admin-bottom {
        align-items: flex-start;
        flex-direction: column;
    }

    .change-status-button {
        width: 100%;
    }

}

/* KARTU HASIL SCAN PESANAN KASIR */
.hasil-pesanan-kasir {
    background: #ffffff;
    border: 1px solid #eeeeee;
    border-radius: 20px;
    padding: 24px;
    margin: 20px 0;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
    color: #222222;
    font-family: Arial, sans-serif;
}

.hasil-pesanan-kasir h3 {
    font-size: 22px;
    margin: 0 0 18px;
}

.hasil-pesanan-kasir h4 {
    font-size: 17px;
    margin: 18px 0 12px;
}

.hasil-pesanan-kasir p {
    font-size: 15px;
    margin: 12px 0;
    line-height: 1.6;
}

.hasil-pesanan-kasir hr {
    border: none;
    border-top: 1px solid #eeeeee;
    margin: 18px 0;
}

.hasil-pesanan-kasir .item-pesanan-scan {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    padding: 10px 0;
    font-size: 15px;
}

<#css akhir>
</style>
 

<body>

    <script src="https://www.gstatic.com/firebasejs/12.1.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore-compat.js"></script>

<script>
const firebaseConfig = {
    apiKey: "AIzaSyB2uWshxlnZWqwGu1yEc1TvMsDGCph40-o",
    authDomain: "qresto-510b7.firebaseapp.com",
    projectId: "qresto-510b7",
    storageBucket: "qresto-510b7.firebasestorage.app",
    messagingSenderId: "125444042497",
    appId: "1:125444042497:web:c6e118614a40631cf1f500",
    measurementId: "G-CFCNW50JC2"
};

/* ================================
   FIREBASE - KONEKSI QResto
   ================================ */

if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

const db = firebase.firestore();


/* ================================
   FIREBASE - SIMPAN PESANAN
   ================================ */

window.simpanPesananFirestore = async function (dataPesanan) {

    await db
        .collection("pesanan")
        .doc(dataPesanan.nomorPesanan)
        .set(dataPesanan);

    console.log(
        "[QResto] Pesanan tersimpan:",
        dataPesanan.nomorPesanan
    );
};



/* ================================
   FIREBASE - CARI DAN BAYAR PESANAN
   ================================ */

window.cariPesananFirestore = async function (nomorPesanan) {
    try {
        const db = firebase.firestore();

        // Bersihkan hasil scan QR
        const nomorBersih = String(nomorPesanan || "")
            .trim()
            .replace(/^#+/, "");

        if (!nomorBersih) {
            console.error("[QResto] Nomor QR kosong.");
            return null;
        }

        // Coba ID dokumen dengan dan tanpa tanda #
        const kandidat = [
            "#" + nomorBersih,
            nomorBersih
        ];

        for (const nomor of kandidat) {
            const snapshot = await db
                .collection("pesanan")
                .doc(nomor)
                .get();

            console.log(
                "[QResto] Mencari dokumen:",
                nomor,
                "| Ditemukan:",
                snapshot.exists
            );

            if (snapshot.exists) {
                const data = snapshot.data();

                console.log(
                    "[QResto] Data pesanan:",
                    data
                );

                return data;
            }
        }

        console.error(
            "[QResto] Pesanan tidak ditemukan. Nomor hasil scan:",
            nomorPesanan
        );

        return null;

    } catch (error) {
        console.error(
            "[QResto] Kesalahan mencari pesanan:",
            error
        );

        return null;
    }
};


/* ================================
   FIREBASE - BAYAR DI KASIR
   ================================ */

window.bayarPesananKasir = async function (nomorPesanan) {
    try {
        const nomorAsli = String(nomorPesanan).trim();
        const nomorTanpaPagar = nomorAsli.replace(/^#+/, "");

        const kandidatNomor = [
            nomorAsli,
            "#" + nomorTanpaPagar,
            nomorTanpaPagar
        ];

        const nomorUnik = [...new Set(kandidatNomor)];

        for (const nomor of nomorUnik) {
            const docRef = db.collection("pesanan").doc(nomor);
            const snap = await docRef.get();

            if (snap.exists) {
                await docRef.update({
                    statusPembayaran: "Dibayar",
                    waktuPembayaran: new Date()
                });

                console.log("[QResto] Pembayaran berhasil:", nomor);
                return true;
            }
        }

        alert("Pesanan tidak ditemukan di Firebase.");
        return false;

    } catch (error) {
        console.error("[QResto] Gagal membayar:", error);
        alert("Gagal memperbarui pembayaran: " + error.message);
        return false;
    }
};
</script>

    <!-- C. HALAMAN WELCOME -->

<div class="app">

    <div class="welcome">

        <div class="logo">
            🍜 QResto
        </div>

        <p class="tagline">
            Pesan makanan jadi lebih mudah
        </p>

        <div class="food-icon">
            🍜
        </div>

        <h1>
            Selamat Datang!
        </h1>

        <p class="description">
            Silakan pesan makanan dan minuman
            favoritmu melalui QResto.
        </p>

        <div class="table-info">
            🪑 Meja 05
        </div>

        <button class="start-button">
            Mulai Pesan →
        </button>

        <button class="admin-button">
    🔐 Admin
</button>

        <p class="footer">
            Scan • Order • Enjoy
        </p>

    </div>

</div>

     <!-- F. HALAMAN PILIH JENIS PESANAN -->

<div class="order-page">

    <div class="order-header">

        <button class="back-button">
            ←
        </button>

        <div>
            <div class="order-logo">
                🍜 QResto
            </div>

            <div class="order-table">
                🪑 Meja 05
            </div>
        </div>

    </div>


    <div class="order-content">

        <p class="step">
            LANGKAH 1
        </p>

        <h1>
            Mau pesan untuk?
        </h1>

        <p class="order-description">
            Pilih jenis pesanan yang kamu inginkan.
        </p>


        <div class="order-options">

            <div class="order-card">

                <div class="order-icon">
                    🍽️
                </div>

                <div class="order-info">

                    <h2>
                        Dine In
                    </h2>

                    <p>
                        Makan langsung di tempat
                    </p>

                </div>

                <span class="arrow">
                    →
                </span>

            </div>


            <div class="order-card">

                <div class="order-icon">
                    🛍️
                </div>

                <div class="order-info">

                    <h2>
                        Takeaway
                    </h2>

                    <p>
                        Bawa pulang pesananmu
                    </p>

                </div>

                <span class="arrow">
                    →
                </span>

            </div>

        </div>

    </div>

</div>


  <!-- E. JAVASCRIPT TOMBOL MULAI PESAN -->

<script>
    const tombolMulai = document.querySelector(".start-button");

    tombolMulai.addEventListener("click", function () {
        alert("Lanjut ke pilihan Dine In / Takeaway");
    });
</script>
  

  <!-- H. NAVIGASI KE HALAMAN PILIH PESANAN -->

<script>
    const halamanAwal = document.querySelector(".app");
    const halamanPesanan = document.querySelector(".order-page");

    const tombolKembaliPesanan = document.querySelector(".back-button");

tombolKembaliPesanan.addEventListener("click", function () {
    halamanPesanan.style.display = "none";
    halamanAwal.style.display = "block";
});

    tombolMulai.addEventListener("click", function () {
        halamanAwal.style.display = "none";
        halamanPesanan.style.display = "block";
    });
</script>

 <!-- I. PILIH DINE IN / TAKEAWAY -->

<script>

    const pilihanDineIn = document.querySelectorAll(".order-card")[0];
    const pilihanTakeaway = document.querySelectorAll(".order-card")[1];



</script>

  <!-- J. HALAMAN MENU -->
   <div class="menu-page">

    <div class="menu-header">

        <div>
            <div class="menu-logo">🍜 QResto</div>
            <div class="menu-info">Meja 05 • Dine In</div>
        </div>

        <button class="cart-button">
            🛒
            <span class="cart-count">0</span>
        </button>

    </div>


    <div class="menu-content">

        <h1>Mau makan apa?</h1>

        <p class="menu-subtitle">
            Pilih makanan dan minuman favoritmu.
        </p>


        <!-- SEARCH -->

        <div class="search-box">

            <span>🔍</span>

            <input
                type="text"
                placeholder="Cari makanan atau minuman..."
            >

        </div>


        <!-- KATEGORI -->

        <div class="categories">

            <button class="category active">
                Semua
            </button>

            <button class="category">
                Makanan
            </button>

            <button class="category">
                Snack
            </button>

            <button class="category">
                Minuman
            </button>

        </div>


        <!-- MENU MAKANAN -->

        <h2 class="section-title">
            Menu Pilihan
        </h2>


        <div class="food-list">


            <!-- MAKANAN 1 -->

            <div class="food-card" data-category="Makanan">

                <div class="food-image">
                    🍜
                </div>

                <div class="food-detail">

                    <h3>
                        Mie Spesial
                    </h3>

                    <p>
                        Mie dengan bumbu khas QResto.
                    </p>

                    <div class="food-bottom">

                        <strong>
                            Rp15.000
                        </strong>

                        <button class="add-button">
                            +
                        </button>

                    </div>

                </div>

            </div>


            <!-- MAKANAN 2 -->

            <div class="food-card" data-category="Makanan">

                <div class="food-image">
                    🌶️
                </div>

                <div class="food-detail">

                    <h3>
                        Mie Level
                    </h3>

                    <p>
                        Mie pedas dengan pilihan level.
                    </p>

                    <div class="food-bottom">

                        <strong>
                            Rp17.000
                        </strong>

                        <button class="add-button">
                            +
                        </button>

                    </div>

                </div>

            </div>


            <!-- SNACK -->

            <div class="food-card" data-category="Snack">

                <div class="food-image">
                    🍢
                </div>

                <div class="food-detail">

                    <h3>
                        Sosis Bakar
                    </h3>

                    <p>
                        Sosis bakar dengan saus spesial.
                    </p>

                    <div class="food-bottom">

                        <strong>
                            Rp10.000
                        </strong>

                        <button class="add-button">
                            +
                        </button>

                    </div>

                </div>

            </div>


            <!-- MINUMAN -->

            <div class="food-card" data-category="Minuman">

                <div class="food-image">
                    🥤
                </div>

                <div class="food-detail">

                    <h3>
                        Es Teh
                    </h3>

                    <p>
                        Es teh manis yang menyegarkan.
                    </p>

                    <div class="food-bottom">

                        <strong>
                            Rp5.000
                        </strong>

                        <button class="add-button">
                            +
                        </button>

                    </div>

                </div>

            </div>


        </div>

    </div>
    <!-- KERANJANG BAWAH MENU -->
<div class="menu-cart-bar">

    <div class="menu-cart-info">
        <strong class="menu-cart-count">0 Item</strong>
        <span class="menu-cart-total">Rp0</span>
    </div>

    <button class="menu-add-more">
        + Tambah Menu Lagi
    </button>

    <button class="menu-cart-open">
        🛒
        <span class="menu-cart-badge">0</span>
    </button>

</div>

</div>


   <!-- L. HUBUNGKAN PILIHAN PESANAN KE MENU -->

<script>
    const halamanMenu = document.querySelector(".menu-page");

    pilihanDineIn.addEventListener("click", function () {

        halamanPesanan.style.display = "none";
        halamanMenu.style.display = "block";

        sessionStorage.setItem(
            "qrestoJenisPesanan",
            "Dine In"
        );

        sessionStorage.setItem(
            "qrestoMejaPesanan",
            "Meja 05"
        );

        document.querySelector(".menu-info").textContent =
            "Meja 05 • Dine In";

        if (typeof tombolBukaDinein !== "undefined") {
            tombolBukaDinein.style.display = "block";
        }

        if (window.qrestoRefreshTampilanPesanan) {
            window.qrestoRefreshTampilanPesanan();
        }

    });


    pilihanTakeaway.addEventListener("click", function () {

        halamanPesanan.style.display = "none";
        halamanMenu.style.display = "block";

        sessionStorage.setItem(
            "qrestoJenisPesanan",
            "Takeaway"
        );

        sessionStorage.removeItem(
            "qrestoMejaPesanan"
        );

        document.querySelector(".menu-info").textContent =
            "Takeaway";

        if (typeof tombolBukaDinein !== "undefined") {
            tombolBukaDinein.style.display = "none";
        }

        if (window.qrestoRefreshTampilanPesanan) {
            window.qrestoRefreshTampilanPesanan();
        }

    });

</script>

<!-- M. HALAMAN DETAIL MENU -->

<div class="detail-page" style="display: none;">

    <div class="detail-header">

        <button class="detail-back">
            ←
        </button>

        <h2>Detail Menu</h2>

        <div class="detail-header-space"></div>

    </div>


    <div class="detail-content">

        <div class="detail-image">
            🍜
        </div>


        <div class="detail-main">

            <p class="detail-category">
                MAKANAN
            </p>

            <h1 class="detail-name">
                Mie Spesial
            </h1>

            <h2 class="detail-price">
                Rp15.000
            </h2>

            <p class="detail-description">
                Mie dengan bumbu khas QResto yang gurih
                dan nikmat.
            </p>


            <!-- PILIH LEVEL -->

            <div class="detail-section">

                <h3 class="option-title">
                 Pilih Level Pedas
                </h3>

                <p class="detail-small option-description">
                    Pilih salah satu level
                </p>

                <div class="level-options">

                    <button class="level-button active">
                        Level 0
                    </button>

                    <button class="level-button">
                        Level 1
                    </button>

                    <button class="level-button">
                        Level 2
                    </button>

                    <button class="level-button">
                        Level 3
                    </button>

                    <button class="level-button">
                        Level 4
                    </button>

                </div>

            </div>


            <!-- CATATAN -->

            <div class="detail-section">

                <h3>
                    Catatan Pesanan
                </h3>

                <textarea
                    class="order-note"
                    placeholder="Contoh: jangan pakai bawang..."
                ></textarea>

            </div>


            <!-- JUMLAH -->

            <div class="quantity-section">

                <div>

                    <h3>Jumlah</h3>

                    <p class="detail-small">
                        Tentukan jumlah pesanan
                    </p>

                </div>


                <div class="quantity-control">

                    <button class="quantity-minus">
                        −
                    </button>

                    <span class="quantity-number">
                        1
                    </span>

                    <button class="quantity-plus">
                        +
                    </button>

                </div>

            </div>


           <div class="detail-cart-row">

    <button class="add-cart-detail">
        <span>
            Tambah ke Keranjang
        </span>

        <strong>
            Rp15.000
        </strong>
    </button>

    <button class="detail-cart-button">
        🛒
        <span class="detail-cart-count">0</span>
    </button>

</div>

        </div>

    </div>

</div>

<!-- O. JAVASCRIPT DETAIL MENU -->

<script>

    // Ambil elemen detail menu
    const halamanDetail = document.querySelector(".detail-page");
    const tombolKembali = document.querySelector(".detail-back");

    // Ambil semua kartu makanan
    const semuaFoodCard = document.querySelectorAll(".food-card");

    // Data harga dan emoji menu
    const dataMenu = [
        {
            nama: "Mie Spesial",
            harga: 15000,
            kategori: "MAKANAN",
            emoji: "🍜",
            deskripsi: "Mie dengan bumbu khas QResto yang gurih dan nikmat."
        },
        {
            nama: "Mie Level",
            harga: 17000,
            kategori: "MAKANAN",
            emoji: "🌶️",
            deskripsi: "Mie pedas dengan pilihan level sesuai selera."
        },
        {
            nama: "Sosis Bakar",
            harga: 10000,
            kategori: "SNACK",
            emoji: "🍢",
            deskripsi: "Sosis bakar dengan saus spesial QResto."
        },
        {
            nama: "Es Teh",
            harga: 5000,
            kategori: "MINUMAN",
            emoji: "🥤",
            deskripsi: "Es teh manis yang menyegarkan."
        }
    ];

    let hargaMenu = 15000;
    let jumlahMenu = 1;

    // Elemen detail
    const detailImage = document.querySelector(".detail-image");
    const detailCategory = document.querySelector(".detail-category");
    const detailName = document.querySelector(".detail-name");
    const detailPrice = document.querySelector(".detail-price");
    const detailDescription = document.querySelector(".detail-description");

    const tombolLevel = document.querySelectorAll(".level-button");

    const tombolMinus = document.querySelector(".quantity-minus");
    const tombolPlus = document.querySelector(".quantity-plus");
    const angkaJumlah = document.querySelector(".quantity-number");

    const tombolTambahDetail =
        document.querySelector(".add-cart-detail");

    const hargaTombol =
        document.querySelector(".add-cart-detail strong");


    // Klik kartu makanan
    semuaFoodCard.forEach(function (card, index) {

        card.addEventListener("click", function () {

            const menu = dataMenu[index];

            if (!menu) {
                return;
            }

            hargaMenu = menu.harga;
            jumlahMenu = 1;

            detailImage.textContent = menu.emoji;
            detailCategory.textContent = menu.kategori;
            detailName.textContent = menu.nama;
            detailPrice.textContent =
                "Rp" + menu.harga.toLocaleString("id-ID");

            detailDescription.textContent =
                menu.deskripsi;
                const judulPilihan =
    document.querySelector(".option-title");

const keteranganPilihan =
    document.querySelector(".option-description");

if (menu.nama === "Es Teh") {

    judulPilihan.textContent = "Pilih Rasa";
    keteranganPilihan.textContent = "Pilih salah satu rasa";

    tombolLevel.forEach(function (button, index) {

        const pilihan = [
            "Original",
            "Lemon",
            "Lychee"
        ];

        if (pilihan[index]) {
            button.style.display = "inline-block";
            button.textContent = pilihan[index];
        } else {
            button.style.display = "none";
        }

    });

} else if (menu.nama === "Sosis Bakar") {

    judulPilihan.textContent = "Pilih Saus";
    keteranganPilihan.textContent = "Pilih salah satu saus";

    tombolLevel.forEach(function (button, index) {

        const pilihan = [
            "BBQ",
            "Pedas",
            "Keju"
        ];

        if (pilihan[index]) {
            button.style.display = "inline-block";
            button.textContent = pilihan[index];
        } else {
            button.style.display = "none";
        }

    });

} else {

    judulPilihan.textContent = "Pilih Level Pedas";
    keteranganPilihan.textContent = "Pilih salah satu level";

    tombolLevel.forEach(function (button, index) {

        button.style.display = "inline-block";
        button.textContent = "Level " + index;

    });

}

tombolLevel.forEach(function (button) {
    button.classList.remove("active");
});

tombolLevel[0].classList.add("active");

            angkaJumlah.textContent = jumlahMenu;

            hargaTombol.textContent =
                "Rp" + menu.harga.toLocaleString("id-ID");

            halamanMenu.style.display = "none";
            halamanDetail.style.display = "block";

        });

    });


    // Tombol kembali
    tombolKembali.addEventListener("click", function () {

        halamanDetail.style.display = "none";
        halamanMenu.style.display = "block";

    });


    // Pilih level pedas
    tombolLevel.forEach(function (button) {

        button.addEventListener("click", function () {

            tombolLevel.forEach(function (btn) {
                btn.classList.remove("active");
            });

            button.classList.add("active");

        });

    });


        // Tombol kurang
    tombolMinus.addEventListener("click", function () {

        if (jumlahMenu > 1) {

            jumlahMenu--;

            angkaJumlah.textContent = jumlahMenu;

            const total =
                hargaMenu * jumlahMenu;

            hargaTombol.textContent =
                "Rp" + total.toLocaleString("id-ID");

        }

    });


    // Tombol tambah
    tombolPlus.addEventListener("click", function () {

        jumlahMenu++;

        angkaJumlah.textContent = jumlahMenu;

        const total =
            hargaMenu * jumlahMenu;

        hargaTombol.textContent =
            "Rp" + total.toLocaleString("id-ID");

    });


</script>

<!-- P. SEARCH DAN KATEGORI MENU -->

<script>
    const inputSearch = document.querySelector(".search-box input");
    const semuaKategori = document.querySelectorAll(".category");

    // SEARCH MENU
    inputSearch.addEventListener("input", function () {
        const kata = inputSearch.value.toLowerCase();

        semuaFoodCard.forEach(function (card) {
            const namaMenu = card.querySelector("h3").textContent.toLowerCase();

            if (namaMenu.includes(kata)) {
                card.style.display = "flex";
            } else {
                card.style.display = "none";
            }
        });
    });

    // KATEGORI MENU
    semuaKategori.forEach(function (kategori) {
        kategori.addEventListener("click", function () {

            semuaKategori.forEach(function (item) {
                item.classList.remove("active");
            });

            kategori.classList.add("active");

            const kategoriDipilih =
                kategori.textContent.trim().toLowerCase();

            semuaFoodCard.forEach(function (card) {
                const kategoriMenu =
                    card.dataset.category.toLowerCase();

                if (
                    kategoriDipilih === "semua" ||
                    kategoriMenu === kategoriDipilih
                ) {
                    card.style.display = "flex";
                } else {
                    card.style.display = "none";
                }
            });
        });
    });
</script>

<!-- S. JAVASCRIPT KERANJANG -->
<script>

document.addEventListener("DOMContentLoaded", function () {

    // =========================
    // DATA KERANJANG
    // =========================
    let keranjang = [];
    window.keranjang = keranjang;

    window.keranjangQResto = keranjang;

    const halamanKeranjang =
        document.querySelector(".cart-page");

    const daftarKeranjang =
        document.querySelector(".cart-items");

    const keranjangKosong =
        document.querySelector(".cart-empty");

    const jumlahKeranjang =
        document.querySelector(".cart-count");

    const subtotalKeranjang =
        document.querySelector(".cart-subtotal");

    const totalKeranjang =
        document.querySelector(".cart-total");

    const tombolTambahMenuLagi =
        document.querySelector(".add-more-menu-button");

    const tombolKeranjangDetail =
        document.querySelector(".detail-cart-button");

    // =========================
    // TAMBAH MENU LAGI
    // =========================
    if (tombolTambahMenuLagi) {
        tombolTambahMenuLagi.addEventListener("click", function () {

            halamanKeranjang.style.display = "none";
            halamanMenu.style.display = "block";

        });
    }

    // =========================
    // BUKA KERANJANG DARI DETAIL
    // =========================
    if (tombolKeranjangDetail) {
        tombolKeranjangDetail.addEventListener("click", function () {

            halamanMenu.style.display = "none";
            halamanDetail.style.display = "none";
            halamanKeranjang.style.display = "block";

            tampilkanKeranjang();

        });
    }

    // =========================
    // KEMBALI DARI KERANJANG
    // =========================
    const tombolKembaliKeranjang =
        document.querySelector(".cart-back");

    if (tombolKembaliKeranjang) {
        tombolKembaliKeranjang.addEventListener("click", function () {

            halamanKeranjang.style.display = "none";
            halamanMenu.style.display = "block";

        });
    }

        // =========================
    // BUKA KERANJANG DARI BAR BAWAH
    // =========================
    const menuCartOpen =
        document.querySelector(".menu-cart-open");

    if (menuCartOpen) {
        menuCartOpen.addEventListener("click", function () {

            halamanMenu.style.display = "none";
            halamanDetail.style.display = "none";
            halamanKeranjang.style.display = "block";

            tampilkanKeranjang();

        });
    }

    // =========================
// TAMBAH MENU LAGI
// =========================
const menuAddMore =
    document.querySelector(".menu-add-more");

if (menuAddMore) {
    menuAddMore.addEventListener("click", function () {

        halamanKeranjang.style.display = "none";
        halamanDetail.style.display = "none";
        halamanMenu.style.display = "block";

    });
}


    // =========================
    // TAMPILKAN KERANJANG
    // =========================
    function tampilkanKeranjang() {

        daftarKeranjang.innerHTML = "";

        if (keranjang.length === 0) {

            keranjangKosong.style.display = "block";
            daftarKeranjang.style.display = "none";

            subtotalKeranjang.textContent = "Rp0";
            totalKeranjang.textContent = "Rp0";

            return;
        }

        keranjangKosong.style.display = "none";
        daftarKeranjang.style.display = "block";

        let total = 0;
        let totalJumlah = 0;

        keranjang.forEach(function (item, index) {

            const subtotal =
                item.harga * item.jumlah;

            total += subtotal;
            totalJumlah += item.jumlah;

            const cartItem =
                document.createElement("div");

            cartItem.className = "cart-item";

            cartItem.innerHTML = `
                <div class="cart-item-image">
                    ${item.emoji}
                </div>

                <div class="cart-item-info">

                    <h3 class="cart-item-name">
                        ${item.nama}
                    </h3>

                    <p class="cart-item-detail">
                        ${item.level}
                    </p>

                    ${
                        item.catatan
                        ? `
                        <p class="cart-item-detail">
                            Catatan: ${item.catatan}
                        </p>
                        `
                        : ""
                    }

                    <strong class="cart-item-price">
                        Rp${subtotal.toLocaleString("id-ID")}
                    </strong>

                </div>

                <div class="cart-item-quantity">

                    <button class="cart-minus">
                        −
                    </button>

                    <span>
                        ${item.jumlah}
                    </span>

                    <button class="cart-plus">
                        +
                    </button>

                </div>
            `;

            // KURANGI JUMLAH
            cartItem
                .querySelector(".cart-minus")
                .addEventListener("click", function () {

                    if (item.jumlah > 1) {
                        item.jumlah--;
                    } else {
                        keranjang.splice(index, 1);
                    }

                    tampilkanKeranjang();

                });

            // TAMBAH JUMLAH
            cartItem
                .querySelector(".cart-plus")
                .addEventListener("click", function () {

                    item.jumlah++;

                    tampilkanKeranjang();

                });

            daftarKeranjang.appendChild(cartItem);

        });

        subtotalKeranjang.textContent =
            "Rp" + total.toLocaleString("id-ID");

        totalKeranjang.textContent =
            "Rp" + total.toLocaleString("id-ID");
                if (jumlahKeranjang) {
            jumlahKeranjang.textContent =
                totalJumlah;
        }

        const menuCartBar =
            document.querySelector(".menu-cart-bar");

        const menuCartCount =
            document.querySelector(".menu-cart-count");

        const menuCartTotal =
            document.querySelector(".menu-cart-total");

        const menuCartBadge =
            document.querySelector(".menu-cart-badge");

        if (menuCartBar) {

            if (totalJumlah > 0) {

                menuCartBar.style.display = "flex";

                menuCartCount.textContent =
                    totalJumlah + " Item";

                menuCartTotal.textContent =
                    "Rp" + total.toLocaleString("id-ID");

                menuCartBadge.textContent =
                    totalJumlah;

            } else {

                menuCartBar.style.display = "none";

            }
        }
    }


    // =========================
    // TAMBAH MENU DARI DETAIL
    // =========================
    tombolTambahDetail.addEventListener(
        
        "click",
        function () {

            const nama =
                detailName.textContent.trim();

            const harga =
                hargaMenu;

            const emoji =
                detailImage.textContent.trim();

            const levelAktif =
                document.querySelector(
                    ".level-button.active"
                );

            const level =
                levelAktif
                ? levelAktif.textContent.trim()
                : "Level 0";

            const catatanElement =
                document.querySelector(".order-note");

            const catatan =
                catatanElement
                ? catatanElement.value.trim()
                : "";

            const itemLama =
                keranjang.find(function (item) {

                    return (
                        item.nama === nama &&
                        item.level === level &&
                        item.catatan === catatan
                    );

                });

            if (itemLama) {

                itemLama.jumlah += jumlahMenu;

            } else {

                keranjang.push({

                    nama: nama,
                    harga: harga,
                    emoji: emoji,
                    level: level,
                    catatan: catatan,
                    jumlah: jumlahMenu

                });

            }

            // HITUNG JUMLAH SEMUA PESANAN
            let jumlahTotal = 0;

            keranjang.forEach(function (item) {

                jumlahTotal += item.jumlah;

            });

            // ANGKA PADA KERANJANG DETAIL
            const detailCartCount =
                document.querySelector(
                    ".detail-cart-count"
                );

            if (detailCartCount) {
                detailCartCount.textContent =
                    jumlahTotal;
            }

            // ANGKA KERANJANG HEADER
            if (jumlahKeranjang) {
                jumlahKeranjang.textContent =
                    jumlahTotal;
            }

            // KOSONGKAN CATATAN
            if (catatanElement) {
                catatanElement.value = "";
            }

            // KEMBALI KE MENU
            halamanDetail.style.display = "none";
            halamanMenu.style.display = "block";
                        tampilkanKeranjang();

        }
    );

});

</script>

<!-- T. HALAMAN PEMBAYARAN -->

<div class="payment-page" style="display: none;">

    <div class="payment-header">

        <button class="payment-back">
            ←
        </button>

        <h2>Pembayaran</h2>

        <div class="payment-header-space"></div>

    </div>


    <div class="payment-content">

        <!-- RINGKASAN PESANAN -->

        <div class="payment-card">

            <h3>Ringkasan Pesanan</h3>

            <div class="payment-summary">

                <span>Total Pesanan</span>

                <strong class="payment-total">
                    Rp0
                </strong>

            </div>

        </div>


        <!-- METODE PEMBAYARAN -->

        <div class="payment-card">

            <h3>Metode Pembayaran</h3>

            <p class="payment-small">
                Pilih salah satu metode pembayaran
            </p>


            <div class="payment-methods">

                <button class="payment-method active">

                    <span class="payment-icon">
                        💵
                    </span>

                    <span>
                        <strong>Kasir</strong>
                        <small>Bayar langsung di kasir</small>
                    </span>

                </button>


                <button class="payment-method">

                    <span class="payment-icon">
                        📱
                    </span>

                    <span>
                        <strong>QRIS / E-Wallet</strong>
                        <small>Bayar menggunakan QRIS</small>
                    </span>

                </button>


                <button class="payment-method">

                    <span class="payment-icon">
                        🏦
                    </span>

                    <span>
                        <strong>Bank Transfer</strong>
                        <small>Transfer melalui rekening bank</small>
                    </span>

                </button>
                <div id="bankTransfer" style="display:none; margin-top:20px; padding:15px; text-align:center; background:#f8f8f8; border-radius:12px;">

    <h3>Transfer Bank</h3>

    <p style="margin-bottom:8px;">
        SeaBank
    </p>

    <strong style="font-size:18px;">
        901473715034
    </strong>

    <p style="margin-top:8px;">
        a.n. Ridwan Nugraha
    </p>

    <p style="font-size:12px; color:#888;">
        Transfer sesuai dengan total pesanan.
    </p>

</div>

            </div>
            <div id="qrEwallet" style="display:none; text-align:center; margin-top:20px;">

    <h3>Scan QR untuk Pembayaran</h3>

    <p>
        Scan QR All Payment menggunakan e-wallet kamu.
    </p>

    <img
        src="qr-allpayment.png"
        alt="QR All Payment"
        style="width:250px; max-width:80%; border-radius:12px;"
    >

    <p style="font-size:12px; color:#888;">
        Pastikan jumlah pembayaran sesuai dengan total pesanan.
    </p>

</div>

        </div>


        <!-- INFO PEMBAYARAN -->

        <div class="payment-info">

            <div class="payment-info-icon">
                ℹ️
            </div>

            <p>
                Pastikan jumlah pembayaran sesuai
                dengan total pesanan.
            </p>

        </div>


        <!-- TOMBOL BAYAR -->

        <button class="pay-button">
            Buat Pesanan & Bayar di Kasir
        </button>

    </div>

</div>

<!-- Q. HALAMAN KERANJANG -->

<div class="cart-page" style="display: none;">

    <div class="cart-header">

        <button class="cart-back">
            ←
        </button>

        <h2>Pesanan Saya</h2>

        <div class="cart-header-space"></div>

    </div>

    <div class="cart-content">
        <p class="cart-subtitle">
         Pesanan kamu
    </p>

    <button class="add-more-menu-button">
    + Tambah Menu Lagi
</button>

<!-- TOMBOL CHECKOUT -->

<button class="checkout-button">
    Lanjut ke Pembayaran
</button>

        <!-- ITEM KERANJANG -->

        <div class="cart-items">

            <div class="cart-item">

                <div class="cart-item-image">
                    🍜
                </div>

                <div class="cart-item-info">

                    <h3 class="cart-item-name">
                        Mie Spesial
                    </h3>

                    <p class="cart-item-detail">
                        Level 0
                    </p>

                    <strong class="cart-item-price">
                        Rp15.000
                    </strong>

                </div>

                <div class="cart-item-quantity">

                    <button class="cart-minus">
                        −
                    </button>

                    <span>1</span>

                    <button class="cart-plus">
                        +
                    </button>

                </div>

            </div>

        </div>


        <!-- KERANJANG KOSONG -->

        <div class="cart-empty" style="display: none;">

            <div class="cart-empty-icon">
                🛒
            </div>

            <h3>Keranjang masih kosong</h3>

            <p>
                Yuk pilih makanan atau minuman terlebih dahulu.
            </p>

        </div>


        <!-- RINGKASAN -->

        <div class="cart-summary">

            <div class="summary-row">
                <span>Subtotal</span>
                <strong class="cart-subtotal">
                    Rp15.000
                </strong>
            </div>

            <div class="summary-row">
                <span>Total</span>
                <strong class="cart-total">
                    Rp15.000
                </strong>
            </div>

        </div>


        
    </div>

</div>


<!-- V. JAVASCRIPT PEMBAYARAN -->

<script>

    const halamanPembayaran =
        document.querySelector(".payment-page");

    const halamanKeranjangPembayaran =
        document.querySelector(".cart-page");

    const tombolCheckout =
        document.querySelector(".checkout-button");

    const tombolKembaliPembayaran =
        document.querySelector(".payment-back");

    const totalPembayaran =
        document.querySelector(".payment-total");

    const totalKeranjangPembayaran =
        document.querySelector(".cart-total");

    const semuaMetodePembayaran =
        document.querySelectorAll(".payment-method");


    tombolCheckout.addEventListener("click", function () {

        halamanKeranjangPembayaran.style.display = "none";
        halamanPembayaran.style.display = "block";

        totalPembayaran.textContent =
            totalKeranjangPembayaran.textContent;

    });


    tombolKembaliPembayaran.addEventListener("click", function () {

        halamanPembayaran.style.display = "none";
        halamanKeranjangPembayaran.style.display = "block";

    });


    semuaMetodePembayaran.forEach(function (metode) {

    metode.addEventListener("click", function () {

        semuaMetodePembayaran.forEach(function (item) {
            item.classList.remove("active");
        });

        metode.classList.add("active");

        const qrEwallet =
            document.getElementById("qrEwallet");

        const bankTransfer =
            document.getElementById("bankTransfer");

        // Sembunyikan semuanya dulu
        if (qrEwallet) {
            qrEwallet.style.display = "none";
        }

        if (bankTransfer) {
            bankTransfer.style.display = "none";
        }

        // QRIS / E-Wallet
        if (metode.textContent.includes("QRIS")) {

            if (qrEwallet) {
                qrEwallet.style.display = "block";
            }

        }

        // Bank Transfer
        else if (metode.textContent.includes("Bank Transfer")) {

            if (bankTransfer) {
                bankTransfer.style.display = "block";
            }

        }

    });

});

</script>


<!-- W. HALAMAN PESANAN BERHASIL -->

<div class="success-page" style="display: none;">

    <div class="success-content">

        <div class="success-icon">
            ✓
        </div>

        <h1 id="judulStatusPesanan">Menunggu Pembayaran</h1>

<p class="success-message" id="pesanStatusPesanan">
    Silakan tunjukkan QR pesanan ini kepada kasir untuk menyelesaikan pembayaran.
</p>

        <div class="order-number">
            <span>Nomor Pesanan</span>
            <strong>#QR2026001</strong>
        </div>

        <div class="order-qr">
    <p>Tunjukkan QR ini ke kasir</p>
    <div id="qrPesanan"></div>
</div>

        <div class="success-info">
            <div>
                <span>Status Pembayaran</span>
                <strong id="statusPembayaranPelanggan">Menunggu Pembayaran</strong>
            </div>

            <div>
                <span>Total</span>
                <strong class="success-total">Rp0</strong>
            </div>
        </div>

        <button class="track-order-button">
            Lihat Status Pesanan
        </button>

        <button class="back-menu-button">
            Kembali ke Menu
        </button>

    </div>

</div>


<!-- Y. JAVASCRIPT PESANAN BERHASIL + STATUS PESANAN -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

<script>
const halamanSukses = document.querySelector(".success-page");
const halamanPembayaran = document.querySelector(".payment-page");
const totalSukses = document.querySelector(".success-total");
const tombolBayar = document.querySelector(".pay-button");
const tombolLihatStatus = document.querySelector(".track-order-button");
const tombolKembaliMenu = document.querySelector(".back-menu-button");

let hentikanPantauanPembayaran = null;
let nomorPesananAktif = null;

function tampilkanStatusPembayaran(status) {
    const judul = document.getElementById("judulStatusPesanan")
        || document.querySelector(".success-content h1");

    const pesan = document.getElementById("pesanStatusPesanan")
        || document.querySelector(".success-message");

    const statusEl = document.getElementById("statusPembayaranPelanggan")
        || document.querySelector(".success-info div:first-child strong");

    if (status === "Dibayar") {
        if (judul) judul.textContent = "Pesanan Berhasil!";
        if (pesan) {
            pesan.textContent =
                "Pembayaran berhasil dikonfirmasi. Terima kasih sudah memesan!";
        }
        if (statusEl) statusEl.textContent = "Sudah Dibayar";
    } else {
        if (judul) judul.textContent = "Menunggu Pembayaran";
        if (pesan) {
            pesan.textContent =
                "Tunjukkan QR pesanan ini kepada kasir untuk menyelesaikan pembayaran.";
        }
        if (statusEl) statusEl.textContent = "Menunggu Pembayaran";
    }
}

if (tombolBayar) {
    tombolBayar.addEventListener("click", async function () {
        if (!window.keranjang || window.keranjang.length === 0) {
            alert("Keranjang masih kosong.");
            return;
        }

        tombolBayar.disabled = true;

        try {
            const nomorPesanan =
                "#QR" + Math.floor(1000000 + Math.random() * 9000000);

            const menuInfo =
                document.querySelector(".menu-info")?.textContent || "";

            const jenisPesanan =
                menuInfo.includes("Takeaway") ? "Takeaway" : "Dine In";

            const mejaMatch = menuInfo.match(/Meja\s*\d+/i);
            const meja = mejaMatch ? mejaMatch[0] : "-";

            const metodeAktif =
                document.querySelector(".payment-method.active");

            const teksMetode = metodeAktif?.textContent || "";

            const metodePembayaran = teksMetode.includes("QRIS")
                ? "QRIS"
                : teksMetode.includes("Bank")
                    ? "Bank Transfer"
                    : "Kasir";

            const items = window.keranjang.map(function (item) {
                return {
                    nama: item.nama,
                    harga: Number(item.harga) || 0,
                    jumlah: Number(item.jumlah) || 1,
                    level: item.level || "",
                    catatan: item.catatan || ""
                };
            });

            const total = items.reduce(function (hasil, item) {
                return hasil + item.harga * item.jumlah;
            }, 0);

            const statusAwal =
                metodePembayaran === "Kasir" ? "Belum Dibayar" : "Dibayar";

            await db.collection("pesanan").doc(nomorPesanan).set({
                nomorPesanan: nomorPesanan,
                jenisPesanan: jenisPesanan,
                meja: meja,
                metodePembayaran: metodePembayaran,
                statusPembayaran: statusAwal,
                statusPesanan: "Baru",
                total: total,
                items: items,
                waktuPesanan: new Date()
            });

            nomorPesananAktif = nomorPesanan;

            const nomorEl = document.querySelector(".order-number strong");
            if (nomorEl) nomorEl.textContent = nomorPesanan;

            if (totalSukses) {
                totalSukses.textContent = "Rp" + total.toLocaleString("id-ID");
            }

            const qrContainer = document.getElementById("qrPesanan");
            if (!qrContainer || typeof QRCode === "undefined") {
                throw new Error("Komponen QR Code belum tersedia.");
            }

            qrContainer.innerHTML = "";
            new QRCode(qrContainer, {
                text: nomorPesanan,
                width: 180,
                height: 180
            });

            tampilkanStatusPembayaran(statusAwal);

            if (halamanPembayaran) halamanPembayaran.style.display = "none";
            if (halamanSukses) halamanSukses.style.display = "flex";

            // Pantau pembayaran kasir langsung dari dokumen Firebase.
            if (hentikanPantauanPembayaran) {
                hentikanPantauanPembayaran();
                hentikanPantauanPembayaran = null;
            }

            if (metodePembayaran === "Kasir") {
                hentikanPantauanPembayaran = db
                    .collection("pesanan")
                    .doc(nomorPesanan)
                    .onSnapshot(function (snapshot) {
                        if (!snapshot.exists) return;

                        const data = snapshot.data();
                        tampilkanStatusPembayaran(
                            data.statusPembayaran || "Belum Dibayar"
                        );
                    }, function (error) {
                        console.error(
                            "Gagal memantau pembayaran:",
                            error
                        );
                    });
            }

            console.log("Pesanan berhasil disimpan:", nomorPesanan);
        } catch (error) {
            console.error("Gagal memproses pesanan:", error);
            alert(
                "Pesanan gagal diproses.\n\n" +
                error.message
            );
        } finally {
            tombolBayar.disabled = false;
        }
    });
}

if (tombolLihatStatus) {
    tombolLihatStatus.addEventListener("click", async function () {
        const nomor = nomorPesananAktif ||
            document.querySelector(".order-number strong")?.textContent;

        if (!nomor || nomor === "-") {
            alert("Nomor pesanan belum tersedia.");
            return;
        }

        try {
            const snapshot = await db.collection("pesanan").doc(nomor).get();

            if (!snapshot.exists) {
                alert("Pesanan tidak ditemukan di Firebase.");
                return;
            }

            const data = snapshot.data();

            alert(
                "Status Pesanan\n\n" +
                "Nomor Pesanan: " + nomor + "\n" +
                "Status Pembayaran: " +
                (data.statusPembayaran || "Belum Dibayar") + "\n" +
                "Status Pesanan: " + (data.statusPesanan || "Baru")
            );
        } catch (error) {
            console.error("Gagal mengecek status pesanan:", error);
            alert("Gagal mengecek status pesanan: " + error.message);
        }
    });
}

if (tombolKembaliMenu) {
    tombolKembaliMenu.addEventListener("click", function () {
        if (hentikanPantauanPembayaran) {
            hentikanPantauanPembayaran();
            hentikanPantauanPembayaran = null;
        }

        if (halamanSukses) halamanSukses.style.display = "none";

        const halamanMenu = document.querySelector(".menu-page");
        if (halamanMenu) halamanMenu.style.display = "block";

        if (window.keranjang) window.keranjang.length = 0;

        if (typeof tampilkanKeranjang === "function") {
            tampilkanKeranjang();
        }
    });
}
</script>

<!-- Z1. FITUR DINE IN -->

<div class="dinein-page" style="display: none;">

    <div class="dinein-header">
        <button class="dinein-back">←</button>
        <h2>Fitur Dine In</h2>
        <div class="dinein-header-space"></div>
    </div>

    <div class="dinein-content">

        <div class="table-info">
            <span>Meja</span>
            <strong>Meja 01</strong>
        </div>

        <div class="dinein-card">
            <div class="dinein-icon">🔔</div>
            <div>
                <h3>Panggil Pelayan</h3>
                <p>Butuh bantuan? Panggil pelayan ke meja kamu.</p>
            </div>
            <button class="call-waiter-button">
                Panggil
            </button>
        </div>

        <div class="dinein-card">
            <div class="dinein-icon">🧾</div>
            <div>
                <h3>Minta Tagihan</h3>
                <p>Jika sudah selesai makan, kamu bisa meminta tagihan.</p>
            </div>
            <button class="request-bill-button">
                Minta
            </button>
        </div>

        <div class="dinein-card rating-card">
            <div class="dinein-icon">⭐</div>

            <div class="rating-content">
                <h3>Beri Penilaian</h3>
                <p>Bagaimana pengalaman kamu hari ini?</p>

                <div class="rating-stars">
                    <button>★</button>
                    <button>★</button>
                    <button>★</button>
                    <button>★</button>
                    <button>★</button>
                </div>

                <textarea
                    class="rating-note"
                    placeholder="Tulis komentar (opsional)..."
                ></textarea>

                <button class="submit-rating-button">
                    Kirim Penilaian
                </button>
            </div>
        </div>

    </div>

</div>

<!-- Z3. JAVASCRIPT FITUR DINE IN -->

<script>
    const halamanDinein = document.querySelector(".dinein-page");
    const tombolKembaliDinein = document.querySelector(".dinein-back");

    const tombolPanggilPelayan =
        document.querySelector(".call-waiter-button");

    const tombolMintaTagihan =
        document.querySelector(".request-bill-button");

    const semuaBintang =
        document.querySelectorAll(".rating-stars button");

    const tombolKirimRating =
        document.querySelector(".submit-rating-button");

    let ratingDipilih = 0;

    // PANGGIL PELAYAN
    tombolPanggilPelayan.addEventListener("click", function () {
        alert("Pelayan berhasil dipanggil ke Meja 01.");
    });

    // MINTA TAGIHAN
    tombolMintaTagihan.addEventListener("click", function () {
        alert(
            "Permintaan tagihan berhasil dikirim.\n\n" +
            "Pelayan akan segera datang ke Meja 01."
        );
    });

    // PILIH RATING
    semuaBintang.forEach(function (bintang, index) {

        bintang.addEventListener("click", function () {

            ratingDipilih = index + 1;

            semuaBintang.forEach(function (item, i) {

                if (i < ratingDipilih) {
                    item.classList.add("active");
                } else {
                    item.classList.remove("active");
                }

            });

        });

    });

    // KIRIM RATING
    tombolKirimRating.addEventListener("click", function () {

        if (ratingDipilih === 0) {
            alert("Silakan pilih rating terlebih dahulu.");
            return;
        }

        alert(
            "Terima kasih!\n\n" +
            "Rating kamu: " +
            ratingDipilih +
            " bintang.\n" +
            "Penilaian berhasil dikirim."
        );

    });

    // KEMBALI
    tombolKembaliDinein.addEventListener("click", function () {

        halamanDinein.style.display = "none";
        halamanMenu.style.display = "block";

    });
</script>


<!-- AA. ADMIN DASHBOARD -->

<div class="admin-page" style="display: none;">

    <div class="admin-header">

        <div>
            <p class="admin-label">QResto</p>
            <h2>Admin Dashboard</h2>
        </div>

        <button class="admin-menu-button">
            ☰
        </button>

    </div>

    <div class="admin-content">

        <!-- STATISTIK -->
        <div class="admin-stats">

            <div class="admin-stat-card">
                <span>📦</span>
                <p>Total Pesanan</p>
                <strong>24</strong>
            </div>

            <div class="admin-stat-card">
                <span>⏳</span>
                <p>Diproses</p>
                <strong>8</strong>
            </div>

            <div class="admin-stat-card">
                <span>💰</span>
                <p>Pendapatan</p>
                <strong>Rp850K</strong>
            </div>

            <div class="admin-stat-card">
                <span>🪑</span>
                <p>Meja Aktif</p>
                <strong>6</strong>
            </div>

        </div>

        <!-- MENU ADMIN -->
        <div class="admin-section">

            <div class="admin-section-title">
                <div>
                    <h3>Kelola Restoran</h3>
                    <p>Akses fitur administrasi QResto</p>
                </div>
            </div>

            <div class="admin-menu-grid">

                <button class="admin-menu-card">
                    <span>🍜</span>
                    <strong>Kelola Menu</strong>
                    <small>Tambah dan ubah menu</small>
                </button>

                <button class="admin-menu-card">
                    <span>📋</span>
                    <strong>Pesanan</strong>
                    <small>Lihat semua pesanan</small>
                </button>

                <button class="admin-menu-card">
                    <span>🪑</span>
                    <strong>Meja & QR</strong>
                    <small>Kelola meja dan QR Code</small>
                </button>

                <button class="admin-menu-card">
                    <span>💳</span>
                    <strong>Pembayaran</strong>
                    <small>Verifikasi pembayaran</small>
                </button>

                <button class="admin-menu-card">
                    <span>📊</span>
                    <strong>Laporan</strong>
                    <small>Lihat laporan restoran</small>
                </button>

                <button class="admin-menu-card">
                    <span>⚙️</span>
                    <strong>Pengaturan</strong>
                    <small>Pengaturan sistem</small>
                </button>

            </div>

        </div>

        <!-- PESANAN TERBARU -->
        <div class="admin-section">

            <div class="admin-section-title">
                <div>
                    <h3>Pesanan Terbaru</h3>
                    <p>Pesanan yang baru masuk</p>
                </div>

                <button class="admin-see-all">
                    Lihat Semua
                </button>
            </div>

            <div class="admin-orders">

                <div class="admin-order">

                    <div>
                        <strong>#QR2026001</strong>
                        <p>Meja 01 • 2 item</p>
                    </div>

                    <div>
                        <strong>Rp30.000</strong>
                        <span class="status-processing">
                            Diproses
                        </span>
                    </div>

                </div>

                <div class="admin-order">

                    <div>
                        <strong>#QR2026002</strong>
                        <p>Meja 03 • 3 item</p>
                    </div>

                    <div>
                        <strong>Rp42.000</strong>
                        <span class="status-new">
                            Baru
                        </span>
                    </div>

                </div>

                <div class="admin-order">

                    <div>
                        <strong>#QR2026003</strong>
                        <p>Meja 05 • 1 item</p>
                    </div>

                    <div>
                        <strong>Rp15.000</strong>
                        <span class="status-done">
                            Selesai
                        </span>
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- AB1. KELOLA MENU ADMIN -->

<div class="admin-menu-page" style="display: none;">

    <div class="admin-header">
        <div>
            <p class="admin-label">QResto</p>
            <h2>Kelola Menu</h2>
        </div>

        <button class="admin-menu-back">←</button>
    </div>

    <div class="admin-content">

        <button class="add-menu-button">
            + Tambah Menu
        </button>

        <div class="menu-admin-list">

            <div class="menu-admin-item">

                <div class="menu-admin-image">🍜</div>

                <div class="menu-admin-info">
                    <strong>Mie Spesial</strong>
                    <span>Makanan</span>
                    <b>Rp15.000</b>
                </div>

                <div class="menu-admin-actions">
                    <button class="edit-menu-button">Edit</button>
                    <button class="delete-menu-button">Hapus</button>
                </div>

            </div>

            <div class="menu-admin-item">

                <div class="menu-admin-image">🌶️</div>

                <div class="menu-admin-info">
                    <strong>Mie Level</strong>
                    <span>Makanan</span>
                    <b>Rp17.000</b>
                </div>

                <div class="menu-admin-actions">
                    <button class="edit-menu-button">Edit</button>
                    <button class="delete-menu-button">Hapus</button>
                </div>

            </div>

            <div class="menu-admin-item">

                <div class="menu-admin-image">🍢</div>

                <div class="menu-admin-info">
                    <strong>Sosis Bakar</strong>
                    <span>Snack</span>
                    <b>Rp10.000</b>
                </div>

                <div class="menu-admin-actions">
                    <button class="edit-menu-button">Edit</button>
                    <button class="delete-menu-button">Hapus</button>
                </div>

            </div>

            <div class="menu-admin-item">

                <div class="menu-admin-image">🥤</div>

                <div class="menu-admin-info">
                    <strong>Es Teh</strong>
                    <span>Minuman</span>
                    <b>Rp5.000</b>
                </div>

                <div class="menu-admin-actions">
                    <button class="edit-menu-button">Edit</button>
                    <button class="delete-menu-button">Hapus</button>
                </div>

            </div>

        </div>

    </div>

</div>


<!-- AB3. JAVASCRIPT CRUD MENU ADMIN -->

<script>
    const halamanAdminMenu =
        document.querySelector(".admin-menu-page");

    const tombolKembaliAdminMenu =
        document.querySelector(".admin-menu-back");

    const tombolTambahMenu =
        document.querySelector(".add-menu-button");

    const daftarMenuAdmin =
        document.querySelector(".menu-admin-list");


    // TOMBOL TAMBAH MENU
    tombolTambahMenu.addEventListener("click", function () {

        const nama = prompt("Masukkan nama menu:");

        if (!nama) {
            return;
        }

        const harga = prompt("Masukkan harga menu:");

        if (!harga) {
            return;
        }

        const kategori = prompt(
            "Masukkan kategori (Makanan / Snack / Minuman):"
        );

        if (!kategori) {
            return;
        }

        const menuBaru =
            document.createElement("div");

        menuBaru.className = "menu-admin-item";

        menuBaru.innerHTML = `
            <div class="menu-admin-image">
                🍽️
            </div>

            <div class="menu-admin-info">
                <strong>${nama}</strong>
                <span>${kategori}</span>
                <b>Rp${Number(harga).toLocaleString("id-ID")}</b>
            </div>

            <div class="menu-admin-actions">
                <button class="edit-menu-button">
                    Edit
                </button>

                <button class="delete-menu-button">
                    Hapus
                </button>
            </div>
        `;

        daftarMenuAdmin.appendChild(menuBaru);

        aktifkanTombolMenu(menuBaru);

        alert("Menu berhasil ditambahkan!");

    });


    // FUNGSI EDIT DAN HAPUS
    function aktifkanTombolMenu(menu) {

        const tombolEdit =
            menu.querySelector(".edit-menu-button");

        const tombolHapus =
            menu.querySelector(".delete-menu-button");


        // EDIT MENU
        tombolEdit.addEventListener("click", function () {

            const namaLama =
                menu.querySelector(".menu-admin-info strong");

            const hargaLama =
                menu.querySelector(".menu-admin-info b");

            const kategoriLama =
                menu.querySelector(".menu-admin-info span");


            const namaBaru =
                prompt(
                    "Ubah nama menu:",
                    namaLama.textContent
                );

            if (namaBaru) {
                namaLama.textContent = namaBaru;
            }


            const hargaBaru =
                prompt(
                    "Ubah harga menu:",
                    hargaLama.textContent
                        .replace("Rp", "")
                        .replace(/\./g, "")
                );

            if (hargaBaru) {
                hargaLama.textContent =
                    "Rp" +
                    Number(hargaBaru)
                        .toLocaleString("id-ID");
            }


            const kategoriBaru =
                prompt(
                    "Ubah kategori:",
                    kategoriLama.textContent
                );

            if (kategoriBaru) {
                kategoriLama.textContent =
                    kategoriBaru;
            }

            alert("Menu berhasil diperbarui!");

        });


        // HAPUS MENU
        tombolHapus.addEventListener("click", function () {

            const nama =
                menu.querySelector(
                    ".menu-admin-info strong"
                ).textContent;

            const yakin =
                confirm(
                    "Hapus menu " +
                    nama +
                    "?"
                );

            if (yakin) {

                menu.remove();

                alert(
                    "Menu berhasil dihapus!"
                );

            }

        });

    }


    // AKTIFKAN TOMBOL PADA MENU YANG SUDAH ADA
    document
        .querySelectorAll(".menu-admin-item")
        .forEach(function (menu) {

            aktifkanTombolMenu(menu);

        });


    // KEMBALI KE DASHBOARD
    tombolKembaliAdminMenu.addEventListener(
        "click",
        function () {

            halamanAdminMenu.style.display = "none";
            document.querySelector(".admin-page")
                .style.display = "block";

        }
    );

</script>


<!-- AB4. HUBUNGKAN DASHBOARD ADMIN KE KELOLA MENU -->

<script>
    const tombolKelolaMenu =
        document.querySelector(".admin-menu-card");

    tombolKelolaMenu.addEventListener("click", function () {

        document.querySelector(".admin-page").style.display = "none";

        halamanAdminMenu.style.display = "block";

    });
</script>

<!-- AC1. HALAMAN MEJA & QR CODE -->

<div class="table-page" style="display: none;">

    <div class="admin-header">

        <div>
            <p class="admin-label">QResto</p>
            <h2>Meja & QR Code</h2>
        </div>

        <button class="table-page-back">
            ←
        </button>

    </div>

    <div class="admin-content">

        <button class="add-table-button">
            + Tambah Meja
        </button>

        <div class="table-grid">

            <!-- MEJA 01 -->
            <div class="table-card">

                <div class="table-card-top">
                    <div class="table-number">
                        Meja 01
                    </div>

                    <span class="table-status available">
                        Tersedia
                    </span>
                </div>

                <div class="qr-placeholder">
                    <div class="qr-symbol">
                        ▦
                    </div>
                    <span>QR Meja 01</span>
                </div>

                <div class="table-actions">

                    <button class="show-qr-button">
                        Lihat QR
                    </button>

                    <button class="delete-table-button">
                        Hapus
                    </button>

                </div>

            </div>


            <!-- MEJA 02 -->
            <div class="table-card">

                <div class="table-card-top">
                    <div class="table-number">
                        Meja 02
                    </div>

                    <span class="table-status occupied">
                        Terisi
                    </span>
                </div>

                <div class="qr-placeholder">
                    <div class="qr-symbol">
                        ▦
                    </div>
                    <span>QR Meja 02</span>
                </div>

                <div class="table-actions">

                    <button class="show-qr-button">
                        Lihat QR
                    </button>

                    <button class="delete-table-button">
                        Hapus
                    </button>

                </div>

            </div>


            <!-- MEJA 03 -->
            <div class="table-card">

                <div class="table-card-top">
                    <div class="table-number">
                        Meja 03
                    </div>

                    <span class="table-status available">
                        Tersedia
                    </span>
                </div>

                <div class="qr-placeholder">
                    <div class="qr-symbol">
                        ▦
                    </div>
                    <span>QR Meja 03</span>
                </div>

                <div class="table-actions">

                    <button class="show-qr-button">
                        Lihat QR
                    </button>

                    <button class="delete-table-button">
                        Hapus
                    </button>

                </div>

            </div>


            <!-- MEJA 04 -->
            <div class="table-card">

                <div class="table-card-top">
                    <div class="table-number">
                        Meja 04
                    </div>

                    <span class="table-status available">
                        Tersedia
                    </span>
                </div>

                <div class="qr-placeholder">
                    <div class="qr-symbol">
                        ▦
                    </div>
                    <span>QR Meja 04</span>
                </div>

                <div class="table-actions">

                    <button class="show-qr-button">
                        Lihat QR
                    </button>

                    <button class="delete-table-button">
                        Hapus
                    </button>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- AC3. JAVASCRIPT MEJA & QR CODE -->

<script>
    const halamanMeja =
        document.querySelector(".table-page");

    const tombolKembaliMeja =
        document.querySelector(".table-page-back");

    const tombolTambahMeja =
        document.querySelector(".add-table-button");

    const daftarMeja =
        document.querySelector(".table-grid");


    // TAMBAH MEJA
    tombolTambahMeja.addEventListener("click", function () {

        const jumlahMeja =
            document.querySelectorAll(".table-card").length + 1;

        const namaMeja =
            "Meja " + String(jumlahMeja).padStart(2, "0");

        const mejaBaru =
            document.createElement("div");

        mejaBaru.className = "table-card";

        mejaBaru.innerHTML = `
            <div class="table-card-top">

                <div class="table-number">
                    ${namaMeja}
                </div>

                <span class="table-status available">
                    Tersedia
                </span>

            </div>

            <div class="qr-placeholder">

                <div class="qr-symbol">
                    ▦
                </div>

                <span>QR ${namaMeja}</span>

            </div>

            <div class="table-actions">

                <button class="show-qr-button">
                    Lihat QR
                </button>

                <button class="delete-table-button">
                    Hapus
                </button>

            </div>
        `;

        daftarMeja.appendChild(mejaBaru);

        aktifkanTombolMeja(mejaBaru);

        alert(
            namaMeja +
            " berhasil ditambahkan!"
        );

    });


    // FUNGSI TOMBOL MEJA
    function aktifkanTombolMeja(meja) {

        const tombolLihatQR =
            meja.querySelector(".show-qr-button");

        const tombolHapus =
            meja.querySelector(".delete-table-button");


        // LIHAT QR
        tombolLihatQR.addEventListener(
            "click",
            function () {

                const nama =
                    meja.querySelector(
                        ".table-number"
                    ).textContent.trim();

                alert(
                    "QR Code " +
                    nama +
                    "\n\n" +
                    "QR Code meja akan digunakan " +
                    "oleh pelanggan untuk membuka menu."
                );

            }
        );


        // HAPUS MEJA
        tombolHapus.addEventListener(
            "click",
            function () {

                const nama =
                    meja.querySelector(
                        ".table-number"
                    ).textContent.trim();

                const yakin =
                    confirm(
                        "Hapus " +
                        nama +
                        "?"
                    );

                if (yakin) {

                    meja.remove();

                    alert(
                        nama +
                        " berhasil dihapus!"
                    );

                }

            }
        );

    }


    // AKTIFKAN TOMBOL MEJA YANG SUDAH ADA
    document
        .querySelectorAll(".table-card")
        .forEach(function (meja) {

            aktifkanTombolMeja(meja);

        });


    // KEMBALI KE DASHBOARD
    tombolKembaliMeja.addEventListener(
        "click",
        function () {

            halamanMeja.style.display = "none";

            document.querySelector(
                ".admin-page"
            ).style.display = "block";

        }
    );

</script>


<!-- AC4. HUBUNGKAN DASHBOARD ADMIN KE MEJA & QR -->

<script>
    const semuaMenuAdmin =
        document.querySelectorAll(".admin-menu-card");

    const tombolMejaQR =
        semuaMenuAdmin[2];

    tombolMejaQR.addEventListener("click", function () {

        document.querySelector(".admin-page").style.display = "none";

        halamanMeja.style.display = "block";

    });
</script>


<!-- AD1. HALAMAN STATUS PESANAN ADMIN -->

<div class="order-admin-page" style="display: none;">

    <div class="admin-header">

        <div>
            <p class="admin-label">QResto</p>
            <h2>Pesanan</h2>
        </div>

        <button class="order-admin-back">
            ←
        </button>

    </div>

    <div class="admin-content">

                <!-- SCANNER QR PESANAN -->
        <div class="cashier-scanner">

            <h3>Scan QR Pesanan</h3>

            <p>Arahkan kamera ke QR yang ditampilkan pelanggan.</p>

            <div id="reader"></div>

            <div id="hasilScanPesanan"></div>

        </div>

        <!-- FILTER STATUS -->
        <div class="order-filter">

            <button class="order-filter-button active">
                Semua
            </button>

            <button class="order-filter-button">
                Baru
            </button>

            <button class="order-filter-button">
                Diproses
            </button>

            <button class="order-filter-button">
                Selesai
            </button>

        </div>


        <!-- DAFTAR PESANAN -->
        <div class="order-admin-list">


            <!-- PESANAN 1 -->
            <div class="order-admin-card">

                <div class="order-admin-top">

                    <div>
                        <strong>#QR2026001</strong>
                        <p>Meja 01 • 2 item</p>
                    </div>

                    <span class="order-status new">
                        Baru
                    </span>

                </div>

                <div class="order-admin-items">

                    <div>
                        <span>Mie Spesial × 1</span>
                        <strong>Rp15.000</strong>
                    </div>

                    <div>
                        <span>Sosis Bakar × 1</span>
                        <strong>Rp10.000</strong>
                    </div>

                </div>

                <div class="order-admin-bottom">

                    <strong>Total Rp25.000</strong>

                    <button class="change-status-button">
                        Ubah Status
                    </button>

                </div>

            </div>


            <!-- PESANAN 2 -->
            <div class="order-admin-card">

                <div class="order-admin-top">

                    <div>
                        <strong>#QR2026002</strong>
                        <p>Meja 03 • 3 item</p>
                    </div>

                    <span class="order-status processing">
                        Diproses
                    </span>

                </div>

                <div class="order-admin-items">

                    <div>
                        <span>Mie Level × 2</span>
                        <strong>Rp34.000</strong>
                    </div>

                    <div>
                        <span>Es Teh × 1</span>
                        <strong>Rp5.000</strong>
                    </div>

                </div>

                <div class="order-admin-bottom">

                    <strong>Total Rp39.000</strong>

                    <button class="change-status-button">
                        Ubah Status
                    </button>

                </div>

            </div>


            <!-- PESANAN 3 -->
            <div class="order-admin-card">

                <div class="order-admin-top">

                    <div>
                        <strong>#QR2026003</strong>
                        <p>Meja 05 • 1 item</p>
                    </div>

                    <span class="order-status done">
                        Selesai
                    </span>

                </div>

                <div class="order-admin-items">

                    <div>
                        <span>Mie Spesial × 1</span>
                        <strong>Rp15.000</strong>
                    </div>

                </div>

                <div class="order-admin-bottom">

                    <strong>Total Rp15.000</strong>

                    <button class="change-status-button">
                        Ubah Status
                    </button>

                </div>

            </div>


        </div>

    </div>

</div>


<!-- AD3. JAVASCRIPT STATUS PESANAN ADMIN -->

<script>
    const halamanPesananAdmin =
        document.querySelector(".order-admin-page");

    const tombolKembaliPesananAdmin =
    document.querySelector(".order-admin-back");

    const semuaFilterPesanan =
        document.querySelectorAll(".order-filter-button");

    const semuaKartuPesanan =
        document.querySelectorAll(".order-admin-card");


    // FILTER PESANAN
    semuaFilterPesanan.forEach(function (filter) {

        filter.addEventListener("click", function () {

            semuaFilterPesanan.forEach(function (item) {
                item.classList.remove("active");
            });

            filter.classList.add("active");

            const filterDipilih =
                filter.textContent.trim().toLowerCase();

            semuaKartuPesanan.forEach(function (pesanan) {

                const statusPesanan =
                    pesanan
                        .querySelector(".order-status")
                        .textContent
                        .trim()
                        .toLowerCase();

                if (
                    filterDipilih === "semua" ||
                    statusPesanan === filterDipilih
                ) {
                    pesanan.style.display = "block";
                } else {
                    pesanan.style.display = "none";
                }

            });

        });

    });

   // SCANNER QR PESANAN
const hasilScanPesanan =
    document.querySelector("#hasilScanPesanan");

async function tampilkanPesananHasilScan(nomorPesanan) {
    try {
        console.log("MENCARI PESANAN:", nomorPesanan);

        const pesanan = await window.cariPesananFirestore(nomorPesanan);

        console.log("DATA PESANAN DITEMUKAN:", pesanan);

        // JIKA PESANAN TIDAK DITEMUKAN
        if (!pesanan) {
            hasilScanPesanan.innerHTML = `
                <div class="hasil-pesanan-kasir">
                    <h3>Pesanan Tidak Ditemukan</h3>
                    <p>Nomor pesanan: ${nomorPesanan}</p>
                </div>
            `;
            return;
        }

        // NORMALISASI DATA PESANAN
        const nomor = pesanan.nomorPesanan || nomorPesanan;
        const items = Array.isArray(pesanan.items) ? pesanan.items : [];
        const metode = pesanan.metodePembayaran || "Kasir";
        const statusBayar = pesanan.statusPembayaran || "Belum Dibayar";
        const total = Number(
            String(pesanan.total || 0).replace(/[^\d]/g, "")
        );

        // TAMPILKAN PESANAN DENGAN GAYA KARTU ADMIN
        hasilScanPesanan.innerHTML = `
            <div class="order-admin-card">
                <div class="order-admin-top">
                    <div>
                        <strong>${nomor}</strong>
                        <p>
                            Meja ${pesanan.meja || "-"}
                            • ${items.length} item
                        </p>
                        <p>${pesanan.jenisPesanan || ""}</p>
                    </div>

                    <span class="order-status ${
                        pesanan.status === "Selesai"
                            ? "done"
                            : pesanan.status === "Diproses"
                            ? "processing"
                            : "new"
                    }">
                        ${pesanan.status || "Baru"}
                    </span>
                </div>

                <div class="order-admin-items">
                    ${
                        items.length
                            ? items.map(function(item) {
                                const jumlah = Number(item.jumlah) || 1;
                                const harga = Number(
                                    String(item.harga || 0).replace(/[^\d]/g, "")
                                );

                                return `
                                    <div>
                                        <span>${item.nama || "Menu"} × ${jumlah}</span>
                                        <strong>Rp${harga.toLocaleString("id-ID")}</strong>
                                    </div>
                                `;
                            }).join("")
                            : "<p>Detail menu tidak tersedia.</p>"
                    }
                </div>

                <div class="order-admin-bottom">
                    <strong>Total Rp${total.toLocaleString("id-ID")}</strong>
                </div>

                <div style="padding-top:15px;">
                    <p>
                        <strong>Metode Pembayaran:</strong>
                        ${metode}
                    </p>

                    <p>
                        <strong>Status Pembayaran:</strong>
                        <span id="statusBayarScan">${statusBayar}</span>
                    </p>

                    ${
                        metode.toLowerCase().includes("kasir") &&
                        statusBayar !== "Dibayar"
                            ? `
                                <button
                                    id="tombolBayarKasir"
                                    style="width:100%;margin-top:15px;padding:14px;border:none;border-radius:12px;background:#28a745;color:white;font-weight:bold;cursor:pointer;"
                                >
                                    ✓ Tandai Sudah Dibayar
                                </button>
                            `
                            : ""
                    }
                </div>
            </div>
        `;

        // TOMBOL KONFIRMASI PEMBAYARAN KASIR
        const tombolBayarKasir =
            document.getElementById("tombolBayarKasir");

        if (tombolBayarKasir) {
            tombolBayarKasir.onclick = async function() {
                tombolBayarKasir.disabled = true;
                tombolBayarKasir.textContent = "Memproses...";

                try {
                    const berhasil = await window.bayarPesananKasir(nomor);

                    if (!berhasil) {
                        throw new Error("Pembayaran gagal dikonfirmasi.");
                    }

                    const elemenStatus =
                        document.getElementById("statusBayarScan");

                    if (elemenStatus) {
                        elemenStatus.textContent = "Dibayar";
                    }

                    tombolBayarKasir.remove();

                    alert("Pembayaran " + nomor + " berhasil dikonfirmasi.");
                } catch (error) {
                    console.error("[QResto] ERROR TOMBOL BAYAR:", error);

                    tombolBayarKasir.disabled = false;
                    tombolBayarKasir.textContent = "✓ Tandai Sudah Dibayar";

                    alert(
                        "Gagal mengubah status pembayaran.\n\n" +
                        error.message
                    );
                }
            };
        }

    } catch (error) {
        console.error("GAGAL MENGAMBIL PESANAN:", error);

        hasilScanPesanan.innerHTML = `
            <div class="hasil-pesanan-kasir">
                <h3>Gagal Mengambil Pesanan</h3>
                <p>${error.message}</p>
            </div>
        `;
    }
}
function mulaiScannerPesanan() {

    const scannerPesanan =
        new Html5Qrcode("reader");

    scannerPesanan.start(
        { facingMode: "environment" },
        {
            fps: 10,
            qrbox: 250
        },

        async function (hasil) {

            await scannerPesanan.stop();

            const nomorPesanan =
                hasil.trim();
                console.log("HASIL QR YANG DISCAN:", nomorPesanan);

            await tampilkanPesananHasilScan(
            nomorPesanan
            );

        },

        function () {
            // Abaikan kesalahan scan sementara
        }
    );

}
    // UBAH STATUS PESANAN
    semuaKartuPesanan.forEach(function (pesanan) {

        const tombolStatus =
            pesanan.querySelector(".change-status-button");

        tombolStatus.addEventListener("click", function () {

            const status =
                pesanan.querySelector(".order-status");

            const nomorPesanan =
                pesanan
                    .querySelector(".order-admin-top strong")
                    .textContent;


            let statusSekarang =
                status.textContent.trim();


            if (statusSekarang === "Baru") {

                status.textContent = "Diproses";

                status.className =
                    "order-status processing";

                alert(
                    nomorPesanan +
                    " sekarang sedang diproses."
                );

            } else if (statusSekarang === "Diproses") {

                status.textContent = "Selesai";

                status.className =
                    "order-status done";

                alert(
                    nomorPesanan +
                    " telah selesai."
                );

            } else {

                alert(
                    nomorPesanan +
                    " sudah selesai."
                );

            }

        });

    });


    // KEMBALI KE DASHBOARD
    tombolKembaliPesananAdmin.addEventListener(
        "click",
        function () {

            halamanPesananAdmin.style.display = "none";

            document.querySelector(
                ".admin-page"
            ).style.display = "block";

        }
    );

</script>


<!-- AD4. HUBUNGKAN DASHBOARD ADMIN KE PESANAN -->

<script>
    const tombolPesananAdmin =
        document.querySelectorAll(".admin-menu-card")[1];

    tombolPesananAdmin.addEventListener("click", function () {

        document.querySelector(".admin-page").style.display = "none";

        halamanPesananAdmin.style.display = "block";
        mulaiScannerPesanan();

    });
</script>


<!-- AE1. HALAMAN LAPORAN & STATISTIK ADMIN -->

<div class="report-page" style="display: none;">

    <div class="admin-header">
        <div>
            <p class="admin-label">QResto</p>
            <h2>Laporan & Statistik</h2>
        </div>

        <button class="report-page-back">←</button>
    </div>

    <div class="admin-content">

        <div class="report-filter">
            <button class="report-filter-button active">Hari Ini</button>
            <button class="report-filter-button">Minggu Ini</button>
            <button class="report-filter-button">Bulan Ini</button>
        </div>

        <div class="report-stats">

            <div class="report-stat-card">
                <span>📦</span>
                <p>Total Pesanan</p>
                <strong>24</strong>
            </div>

            <div class="report-stat-card">
                <span>💰</span>
                <p>Total Pendapatan</p>
                <strong>Rp850.000</strong>
            </div>

            <div class="report-stat-card">
                <span>🍜</span>
                <p>Menu Terjual</p>
                <strong>47</strong>
            </div>

            <div class="report-stat-card">
                <span>⭐</span>
                <p>Rating</p>
                <strong>4,8</strong>
            </div>

        </div>

        <div class="report-card">

            <div class="report-card-title">
                <div>
                    <h3>Pendapatan</h3>
                    <p>Ringkasan pendapatan restoran</p>
                </div>
            </div>

            <div class="report-chart">

                <div class="chart-bar">
                    <span>Sen</span>
                    <div class="bar">
                        <i style="height: 45%;"></i>
                    </div>
                    <b>120K</b>
                </div>

                <div class="chart-bar">
                    <span>Sel</span>
                    <div class="bar">
                        <i style="height: 65%;"></i>
                    </div>
                    <b>180K</b>
                </div>

                <div class="chart-bar">
                    <span>Rab</span>
                    <div class="bar">
                        <i style="height: 50%;"></i>
                    </div>
                    <b>140K</b>
                </div>

                <div class="chart-bar">
                    <span>Kam</span>
                    <div class="bar">
                        <i style="height: 80%;"></i>
                    </div>
                    <b>220K</b>
                </div>

                <div class="chart-bar">
                    <span>Jum</span>
                    <div class="bar">
                        <i style="height: 70%;"></i>
                    </div>
                    <b>190K</b>
                </div>

                <div class="chart-bar">
                    <span>Sab</span>
                    <div class="bar">
                        <i style="height: 90%;"></i>
                    </div>
                    <b>250K</b>
                </div>

                <div class="chart-bar">
                    <span>Min</span>
                    <div class="bar">
                        <i style="height: 60%;"></i>
                    </div>
                    <b>160K</b>
                </div>

            </div>

        </div>

        <div class="report-card">

            <div class="report-card-title">
                <div>
                    <h3>Menu Terlaris</h3>
                    <p>Menu yang paling banyak dipesan</p>
                </div>
            </div>

            <div class="best-menu-list">

                <div class="best-menu-item">
                    <span>🥇</span>
                    <div>
                        <strong>Mie Spesial</strong>
                        <small>18 terjual</small>
                    </div>
                    <b>Rp270K</b>
                </div>

                <div class="best-menu-item">
                    <span>🥈</span>
                    <div>
                        <strong>Mie Level</strong>
                        <small>12 terjual</small>
                    </div>
                    <b>Rp204K</b>
                </div>

                <div class="best-menu-item">
                    <span>🥉</span>
                    <div>
                        <strong>Sosis Bakar</strong>
                        <small>10 terjual</small>
                    </div>
                    <b>Rp100K</b>
                </div>

                <div class="best-menu-item">
                    <span>🏅</span>
                    <div>
                        <strong>Es Teh</strong>
                        <small>7 terjual</small>
                    </div>
                    <b>Rp35K</b>
                </div>

            </div>

        </div>

    </div>

</div>


<style>
/* AE2. CSS LAPORAN & STATISTIK */

.report-page {
    min-height: 100vh;
    background: #f7f7f7;
}

.report-page .admin-header {
    position: sticky;
    top: 0;
    z-index: 10;
}

.report-page-back {
    width: 42px;
    height: 42px;
    border: none;
    border-radius: 12px;
    background: #f5f5f5;
    font-size: 22px;
    cursor: pointer;
}

.report-filter {
    display: flex;
    gap: 8px;
    overflow-x: auto;
    padding-bottom: 5px;
}

.report-filter-button {
    flex-shrink: 0;
    padding: 9px 14px;
    border: 1px solid #eeeeee;
    border-radius: 10px;
    background: #ffffff;
    color: #777777;
    font-size: 11px;
    font-weight: bold;
    cursor: pointer;
}

.report-filter-button.active {
    background: #ff7a00;
    border-color: #ff7a00;
    color: #ffffff;
}

.report-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 13px;
    margin-top: 18px;
}

.report-stat-card {
    padding: 17px;
    background: #ffffff;
    border: 1px solid #eeeeee;
    border-radius: 17px;
}

.report-stat-card > span {
    font-size: 22px;
}

.report-stat-card p {
    margin: 10px 0 5px;
    color: #888888;
    font-size: 11px;
}

.report-stat-card strong {
    font-size: 18px;
}

.report-card {
    margin-top: 20px;
    padding: 18px;
    background: #ffffff;
    border: 1px solid #eeeeee;
    border-radius: 18px;
}

.report-card-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.report-card-title h3 {
    margin: 0 0 4px;
    font-size: 16px;
}

.report-card-title p {
    margin: 0;
    color: #999999;
    font-size: 11px;
}

.report-chart {
    height: 230px;
    margin-top: 20px;
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 8px;
    border-bottom: 1px solid #eeeeee;
}

.chart-bar {
    height: 100%;
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: flex-end;
    gap: 6px;
}

.chart-bar > span {
    color: #999999;
    font-size: 10px;
}

.chart-bar b {
    color: #777777;
    font-size: 9px;
    font-weight: normal;
}

.chart-bar .bar {
    width: 100%;
    max-width: 32px;
    height: 150px;
    display: flex;
    align-items: flex-end;
    background: #f5f5f5;
    border-radius: 8px 8px 0 0;
    overflow: hidden;
}

.chart-bar .bar i {
    width: 100%;
    display: block;
    background: #ff7a00;
    border-radius: 8px 8px 0 0;
}

.best-menu-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-top: 18px;
}

.best-menu-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 13px;
    background: #f8f8f8;
    border-radius: 13px;
}

.best-menu-item > span {
    font-size: 22px;
}

.best-menu-item div {
    flex: 1;
    min-width: 0;
}

.best-menu-item strong {
    display: block;
    font-size: 13px;
}

.best-menu-item small {
    display: block;
    margin-top: 4px;
    color: #999999;
    font-size: 10px;
}

.best-menu-item b {
    color: #ff7a00;
    font-size: 12px;
}

@media (max-width: 700px) {

    .report-stats {
        grid-template-columns: repeat(2, 1fr);
    }

}

@media (max-width: 450px) {

    .report-stats {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }

    .report-stat-card {
        padding: 14px;
    }

    .report-chart {
        height: 200px;
    }

    .chart-bar .bar {
        height: 125px;
    }

}
</style>


<!-- AE3. JAVASCRIPT LAPORAN & STATISTIK ADMIN -->

<script>
    const halamanLaporan = document.querySelector(".report-page");
    const tombolKembaliLaporan =
        document.querySelector(".report-page-back");

    const semuaFilterLaporan =
        document.querySelectorAll(".report-filter-button");

    semuaFilterLaporan.forEach(function (filter) {

        filter.addEventListener("click", function () {

            semuaFilterLaporan.forEach(function (item) {
                item.classList.remove("active");
            });

            filter.classList.add("active");

            const periode =
                filter.textContent.trim();

            alert(
                "Laporan " +
                periode +
                "\n\nData laporan berhasil ditampilkan."
            );

        });

    });

    tombolKembaliLaporan.addEventListener("click", function () {

        halamanLaporan.style.display = "none";

        document.querySelector(".admin-page").style.display = "block";

    });
</script>


<!-- AE4. HUBUNGKAN DASHBOARD ADMIN KE LAPORAN -->

<script>
    const tombolLaporanAdmin =
        document.querySelectorAll(".admin-menu-card")[4];

    tombolLaporanAdmin.addEventListener("click", function () {

        document.querySelector(".admin-page").style.display = "none";

        halamanLaporan.style.display = "block";

    });
</script>


<!-- AF1. CSS FINISHING & RESPONSIVE -->

<style>
    /* Membuat semua halaman tidak melebar ke samping */
    .menu-page,
    .detail-page,
    .cart-page,
    .payment-page,
    .success-page,
    .dinein-page,
    .admin-page,
.admin-menu-page,
.table-page,
.order-admin-page,
.report-page {
    width: 100vw;
    min-width: 100vw;
    min-height: 100vh;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    overflow-x: hidden;
}
    
    /* FIX ADMIN DASHBOARD */
.admin-page {
    position: fixed !important;
    top: 0;
    left: 0;
    width: 100vw !important;
    height: 100vh;
    min-height: 100vh;
    margin: 0;
    background: #f7f7f7;
    overflow-y: auto;
    overflow-x: hidden;
    box-sizing: border-box;
}

.admin-header {
    padding-left: max(25px, calc((100vw - 1100px) / 2));
    padding-right: max(25px, calc((100vw - 1100px) / 2));
}

.admin-content {
    width: 100%;
    max-width: 1100px;
    margin: 0 auto;
    padding: 20px 25px 35px;
    box-sizing: border-box;
}
    /* Efek tombol agar lebih halus */
    button {
        transition: 0.2s ease;
    }

    button:active {
        transform: scale(0.97);
    }

    /* Tampilan tablet */
    @media (max-width: 800px) {

        .admin-stats,
        .report-stats {
            grid-template-columns: repeat(2, 1fr);
        }

        .admin-menu-grid {
            grid-template-columns: repeat(2, 1fr);
        }

    }

    /* Tampilan HP */
    @media (max-width: 600px) {

        .admin-header {
            padding: 18px 15px;
        }

        .admin-content {
            padding: 18px 15px 30px;
        }

        .admin-stats,
        .report-stats {
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }

        .admin-stat-card,
        .report-stat-card {
            padding: 14px;
        }

        .admin-stat-card strong,
        .report-stat-card strong {
            font-size: 16px;
        }

        .admin-menu-grid {
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .admin-menu-card {
            padding: 14px;
        }

        .table-grid {
            grid-template-columns: 1fr;
        }

        .cart-content,
        .payment-content,
        .detail-content,
        .dinein-content {
            padding-left: 15px;
            padding-right: 15px;
        }

    }

    /* HP kecil */
    @media (max-width: 400px) {

        .admin-menu-grid {
            grid-template-columns: 1fr;
        }

        .admin-stats,
        .report-stats {
            grid-template-columns: 1fr 1fr;
        }

        .admin-stat-card p,
        .report-stat-card p {
            font-size: 10px;
        }

        .admin-stat-card strong,
        .report-stat-card strong {
            font-size: 15px;
        }

        .cart-item {
            gap: 8px;
            padding: 11px;
        }

        .cart-item-image {
            width: 50px;
            height: 50px;
        }

        .cart-item-quantity {
            gap: 3px;
        }

    }
</style>


<!-- AF2. HUBUNGKAN FITUR DINE IN -->

<script>
    const tombolBukaDinein = document.createElement("button");

    tombolBukaDinein.textContent = "🍽️ Fitur Dine In";
    tombolBukaDinein.className = "dinein-menu-button";

    const menuHeader = document.querySelector(".menu-header");

    if (menuHeader) {
        menuHeader.appendChild(tombolBukaDinein);
    }

    tombolBukaDinein.addEventListener("click", function () {

        halamanMenu.style.display = "none";
        halamanDetail.style.display = "none";
        halamanKeranjang.style.display = "none";
        halamanPembayaran.style.display = "none";
        halamanSukses.style.display = "none";

        halamanDinein.style.display = "block";

    });
</script>




<!-- AF4. PERAPIHAN ALUR ADMIN -->

<script>
    const halamanAdmin = document.querySelector(".admin-page");

    // Semua halaman admin
    const semuaHalamanAdmin = [
        halamanAdmin,
        halamanAdminMenu,
        halamanMeja,
        halamanPesananAdmin,
        halamanLaporan
    ];

    function sembunyikanSemuaHalamanAdmin() {
        semuaHalamanAdmin.forEach(function (halaman) {
            if (halaman) {
                halaman.style.display = "none";
            }
        });
    }

    function bukaDashboardAdmin() {
        sembunyikanSemuaHalamanAdmin();
        halamanAdmin.style.display = "block";
    }

    // Tombol kembali dari Kelola Menu
    tombolKembaliAdminMenu.addEventListener("click", function () {
        bukaDashboardAdmin();
    });

    // Tombol kembali dari Meja & QR
    tombolKembaliMeja.addEventListener("click", function () {
        bukaDashboardAdmin();
    });

    // Tombol kembali dari Pesanan
    tombolKembaliPesananAdmin.addEventListener("click", function () {
        bukaDashboardAdmin();
    });

    // Tombol kembali dari Laporan
    tombolKembaliLaporan.addEventListener("click", function () {
        bukaDashboardAdmin();
    });
</script>


<!-- AF5. FINAL TESTING SISTEM -->

<script>
    console.log("=== QResto Final Testing ===");

    const cekElemen = [
        [".menu-page", "Halaman Menu"],
        [".detail-page", "Halaman Detail"],
        [".cart-page", "Keranjang"],
        [".payment-page", "Pembayaran"],
        [".success-page", "Pesanan Berhasil"],
        [".dinein-page", "Dine In"],
        [".admin-page", "Dashboard Admin"],
        [".admin-menu-page", "Kelola Menu"],
        [".table-page", "Meja & QR"],
        [".order-admin-page", "Pesanan Admin"],
        [".report-page", "Laporan"]
    ];

    let jumlahBerhasil = 0;

    cekElemen.forEach(function (data) {

        const elemen = document.querySelector(data[0]);

        if (elemen) {
            console.log("✓ " + data[1] + " tersedia");
            jumlahBerhasil++;
        } else {
            console.log("✗ " + data[1] + " tidak ditemukan");
        }

    });

    console.log(
        "QResto: " +
        jumlahBerhasil +
        "/" +
        cekElemen.length +
        " halaman berhasil ditemukan."
    );
</script>


<!-- AF6. FINISHING AKHIR QResto -->

<style>
    /* Tampilan scrollbar agar lebih rapi */
    ::-webkit-scrollbar {
        width: 7px;
        height: 7px;
    }

    ::-webkit-scrollbar-track {
        background: #f5f5f5;
    }

    ::-webkit-scrollbar-thumb {
        background: #cccccc;
        border-radius: 10px;
    }

    /* Efek fokus untuk input */
    input:focus,
    textarea:focus,
    button:focus {
        outline: none;
    }

    /* Mencegah gambar atau elemen keluar layar */
    img {
        max-width: 100%;
    }

    /* Animasi muncul halaman */
    .menu-page,
    .detail-page,
    .cart-page,
    .payment-page,
    .success-page,
    .dinein-page,
    .admin-page,
    .admin-menu-page,
    .table-page,
    .order-admin-page,
    .report-page {
        animation: halamanMuncul 0.25s ease;
    }

    @keyframes halamanMuncul {
        from {
            opacity: 0;
            transform: translateY(5px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Tampilan HP */
    @media (max-width: 500px) {

        .detail-name {
            font-size: 24px;
        }

        .detail-image {
            height: 210px;
        }

        .success-content {
            max-width: 100%;
        }

        .success-content h1 {
            font-size: 23px;
        }

    }
</style>

<script>
    // AF6. CEK AKHIR QResto

    console.log("================================");
    console.log("       QResto Final Check");
    console.log("================================");

    console.log("✓ Customer Menu siap");
    console.log("✓ Detail Menu siap");
    console.log("✓ Keranjang siap");
    console.log("✓ Pembayaran siap");
    console.log("✓ Pesanan Berhasil siap");
    console.log("✓ Fitur Dine In siap");
    console.log("✓ Dashboard Admin siap");
    console.log("✓ Kelola Menu siap");
    console.log("✓ Meja & QR siap");
    console.log("✓ Pesanan Admin siap");
    console.log("✓ Laporan & Statistik siap");

    console.log("================================");
    console.log("       QResto siap digunakan!");
    console.log("================================");
</script>


<!-- AF7. PERBAIKAN TAMPILAN WELCOME -->
<style>
    @media (max-height: 750px) {
        .welcome {
            padding: 20px 25px;
        }

        .food-icon {
            width: 120px;
            height: 120px;
            margin: 25px 0 20px;
            font-size: 60px;
        }

        .welcome h1 {
            font-size: 27px;
            margin-bottom: 8px;
        }

        .table-info {
            margin-top: 18px;
        }

        .start-button {
            margin-top: 18px;
            padding: 14px;
        }

        .footer {
            margin-top: 15px;
        }
    }
</style>


<!-- AF8. SISTEM JENIS PESANAN + KASIR -->
<script>

(function () {

    function ambilJenisPesanan() {

        return {
            jenis:
                sessionStorage.getItem(
                    "qrestoJenisPesanan"
                ) || "",

            meja:
                sessionStorage.getItem(
                    "qrestoMejaPesanan"
                ) || ""
        };

    }


    function teksJenisPesanan() {

        const data = ambilJenisPesanan();

        if (data.jenis === "Dine In") {

            return "🪑 DINE IN • " + data.meja;

        }

        if (data.jenis === "Takeaway") {

            return "🛍️ TAKEAWAY";

        }

        return "Jenis pesanan belum dipilih";

    }


    function buatInfoPesanan(id, judul, isi) {

        let info = document.getElementById(id);

        if (!info) {

            info = document.createElement("div");

            info.id = id;

            info.style.marginBottom = "18px";
            info.style.padding = "14px";
            info.style.border = "1px solid #eeeeee";
            info.style.borderRadius = "16px";
            info.style.background = "#fff8f2";

        }

        info.innerHTML = `
            <strong style="
                display:block;
                font-size:12px;
                color:#888;
                margin-bottom:5px;
            ">
                ${judul}
            </strong>

            <div style="
                font-size:15px;
                font-weight:bold;
                color:#333;
            ">
                ${isi}
            </div>
        `;

        return info;

    }


    function refreshTampilanPesanan() {

        const data = ambilJenisPesanan();

        /* MENU */

        const menuInfo =
            document.querySelector(".menu-info");

        if (menuInfo) {

            if (data.jenis === "Dine In") {

                menuInfo.textContent =
                    data.meja + " • Dine In";

            } else if (data.jenis === "Takeaway") {

                menuInfo.textContent =
                    "Takeaway";

            }

        }


        /* TOMBOL DINE IN */

        if (
            typeof tombolBukaDinein !== "undefined"
        ) {

            if (data.jenis === "Dine In") {

                tombolBukaDinein.style.display =
                    "block";

            } else {

                tombolBukaDinein.style.display =
                    "none";

            }

        }


        /* HALAMAN DINE IN */

        const nomorMejaDineIn =
            document.querySelector(
                ".dinein-page .table-info strong"
            );

        if (nomorMejaDineIn) {

            nomorMejaDineIn.textContent =
                data.meja || "-";

        }


        /* KERANJANG */

        const cartContent =
            document.querySelector(".cart-content");

        if (cartContent) {

            const subtitle =
                cartContent.querySelector(
                    ".cart-subtitle"
                );

            if (subtitle) {

                const infoCart =
                    buatInfoPesanan(
                        "qresto-cart-context",
                        "JENIS PESANAN",
                        teksJenisPesanan()
                    );

                subtitle.after(infoCart);

            }

        }


        /* PEMBAYARAN */

        const paymentContent =
            document.querySelector(".payment-content");

        if (paymentContent) {

            const paymentCard =
                paymentContent.querySelector(
                    ".payment-card"
                );

            if (paymentCard) {

                const infoPayment =
                    buatInfoPesanan(
                        "qresto-payment-context",
                        "JENIS PESANAN",
                        teksJenisPesanan()
                    );

                paymentCard.before(infoPayment);

            }

        }


        /* PESANAN BERHASIL */

        const orderNumber =
            document.querySelector(".order-number");

        if (orderNumber) {

            const infoSuccess =
                buatInfoPesanan(
                    "qresto-success-context",
                    "JENIS PESANAN",
                    teksJenisPesanan()
                );

            orderNumber.before(infoSuccess);

        }


    }


    /* SIMPAN PESANAN TERAKHIR */

    window.qrestoBuatPesananTerakhir =
        async function () {

            const data =
                ambilJenisPesanan();

            const semuaItem =
                Array.from(
                    document.querySelectorAll(
                        ".cart-item"
                    )
                );


            const daftarItem =
                semuaItem.map(function (item) {

                    const nama =
                        item.querySelector(
                            ".cart-item-name"
                        );

                    const detail =
                        item.querySelector(
                            ".cart-item-detail"
                        );

                    const harga =
                        item.querySelector(
                            ".cart-item-price"
                        );

                    const jumlah =
                        item.querySelector(
                            ".cart-item-quantity span"
                        );

                    return {

                        nama: nama
                            ? nama.textContent.trim()
                            : "",

                        detail: detail
                            ? detail.textContent.trim()
                            : "",

                        harga: harga
                            ? harga.textContent.trim()
                            : "",

                        jumlah: jumlah
                            ? jumlah.textContent.trim()
                            : "1"

                    };

                });


            const metodeAktif =
                document.querySelector(
                    ".payment-method.active strong"
                );


            const total =
                document.querySelector(
                    ".payment-total"
                );


            const nomorPesanan =
                "#QR" +
                String(Date.now()).slice(-7);


            const pesanan = {

                nomor:
                    nomorPesanan,

                jenis:
                    data.jenis,

                meja:
                    data.meja,

                metodePembayaran:
                    metodeAktif
                    ? metodeAktif.textContent.trim()
                    : "Kasir",

                total:
                    total
                    ? total.textContent.trim()
                    : "Rp0",

                status:
                    "Baru",

                items:
                    daftarItem

            };


            sessionStorage.setItem(
                "qrestoPesananTerakhir",
                JSON.stringify(pesanan)
            );

            if (window.simpanPesananFirestore) {
    try {
        await window.simpanPesananFirestore({
            nomorPesanan: pesanan.nomor,
            jenisPesanan: pesanan.jenis,
            meja: pesanan.meja,
            metodePembayaran: pesanan.metodePembayaran,
            statusPembayaran: "Belum Dibayar",
            statusPesanan: pesanan.status,
            total: pesanan.total,
            items: pesanan.items
        });

        console.log(
            "[QResto] Pesanan berhasil disimpan:",
            pesanan.nomor
        );

    } catch (error) {
        console.error(
            "[QResto] Gagal menyimpan pesanan:",
            error
        );

        alert("Pesanan gagal disimpan ke Firebase.");
        return;
    }
}


            /* NOMOR PESANAN CUSTOMER */

            const nomorSuccess =
                document.querySelector(
                    ".order-number strong"
                );

            if (nomorSuccess) {

                nomorSuccess.textContent =
                    pesanan.nomor;

            }

            const qrContainer = document.querySelector("#qrPesanan");

if (qrContainer) {
    qrContainer.innerHTML = "";

    new QRCode(qrContainer, {
        text: pesanan.nomor.replace("#", ""),
        width: 180,
        height: 180
    });
}


            /* SIMPAN INFO PEMBAYARAN */

            refreshTampilanPesanan();

            renderPesananKasir();

        };


    /* RENDER PESANAN KE HALAMAN KASIR */

    function renderPesananKasir() {

        const data =
            sessionStorage.getItem(
                "qrestoPesananTerakhir"
            );

        if (!data) {
            return;
        }


        const pesanan =
            JSON.parse(data);


        /* DAFTAR PESANAN ADMIN */

        const daftarAdmin =
            document.querySelector(
                ".order-admin-list"
            );

        if (daftarAdmin) {

            const lama =
                daftarAdmin.querySelector(
                    ".live-order-card"
                );

            if (lama) {
                lama.remove();
            }


            const kartu =
                document.createElement("div");

            kartu.className =
                "order-admin-card live-order-card";


            const teksLokasi =
                pesanan.jenis === "Dine In"
                ? pesanan.meja
                : "Takeaway";


            kartu.innerHTML = `

                <div class="order-admin-top">

                    <div>

                        <strong>
                            ${pesanan.nomor}
                        </strong>

                        <p>
                            ${teksLokasi}
                            • ${pesanan.items.length} item
                        </p>

                        <p>
                            ${pesanan.metodePembayaran}
                        </p>

                    </div>

                    <span class="order-status new">
                        ${pesanan.status}
                    </span>

                </div>


                <div class="order-admin-items">

                    ${
                        pesanan.items.map(function (item) {

                            return `
                                <div>

                                    <span>
                                        ${item.nama}
                                        × ${item.jumlah}
                                    </span>

                                    <strong>
                                        ${item.harga}
                                    </strong>

                                </div>
                            `;

                        }).join("")
                    }

                </div>


                <div class="order-admin-bottom">

                    <strong>
                        Total ${pesanan.total}
                    </strong>

                    <button
                        class="change-status-button live-status-button"
                    >
                        Ubah Status
                    </button>

                </div>

            `;


            daftarAdmin.prepend(kartu);


            const tombolStatus =
                kartu.querySelector(
                    ".live-status-button"
                );


            tombolStatus.addEventListener(
                "click",
                function () {

                    const statusSekarang =
                        pesanan.status;


                    if (
                        statusSekarang === "Baru"
                    ) {

                        pesanan.status =
                            "Diproses";

                    } else if (
                        statusSekarang === "Diproses"
                    ) {

                        pesanan.status =
                            "Selesai";

                    } else {

                        pesanan.status =
                            "Baru";

                    }


                    sessionStorage.setItem(
                        "qrestoPesananTerakhir",
                        JSON.stringify(pesanan)
                    );


                    renderPesananKasir();

                }
            );

        }


        /* DASHBOARD ADMIN */

        const daftarDashboard =
            document.querySelector(
                ".admin-orders"
            );

        if (daftarDashboard) {

            const lamaDashboard =
                daftarDashboard.querySelector(
                    ".live-admin-order"
                );

            if (lamaDashboard) {
                lamaDashboard.remove();
            }


            const ringkasan =
                document.createElement("div");

            ringkasan.className =
                "admin-order live-admin-order";


            const lokasi =
                pesanan.jenis === "Dine In"
                ? pesanan.meja
                : "Takeaway";


            ringkasan.innerHTML = `

                <div>

                    <strong>
                        ${pesanan.nomor}
                    </strong>

                    <p>
                        ${lokasi}
                        • ${pesanan.items.length} item
                    </p>

                </div>


                <div>

                    <strong>
                        ${pesanan.total}
                    </strong>

                    <span class="status-new">
                        ${pesanan.status}
                    </span>

                </div>

            `;


            daftarDashboard.prepend(
                ringkasan
            );

        }

    }


    window.qrestoRefreshTampilanPesanan =
        refreshTampilanPesanan;


    /* SAAT HALAMAN DIBUKA */

    refreshTampilanPesanan();

    renderPesananKasir();


})();

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="https://unpkg.com/html5-qrcode"></script>


<script>
    const tombolAdmin = document.querySelector(".admin-button");

    tombolAdmin.addEventListener("click", function () {
        document.querySelector(".welcome").style.display = "none";
        bukaDashboardAdmin();
    });
</script>

<style>
    /* Tampilan khusus halaman admin */
    .welcome,
    .order-page,
    .menu-page,
    .detail-page,
    .cart-page,
    .payment-page,
    .success-page,
    .dinein-page {
        display: none !important;
    }
</style>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const dashboard = document.querySelector(".admin-page");

    if (dashboard) {
        dashboard.style.display = "block";
    }
});
</script>

</body>

</html><?php /**PATH C:\xampp\htdocs\QResto\resources\views/admin.blade.php ENDPATH**/ ?>