<!-- AB1. KELOLA MENU ADMIN -->

<div class="admin-menu-page" style="display: none;">

    <div class="admin-header">
        <div>
            <p class="admin-label">QResto</p>
            <h2>Kelola Menu</h2>
        </div>

        <button class="admin-menu-back">←</button>
    </div>

    <div class="admin-content">

        <button class="add-menu-button">
            + Tambah Menu
        </button>

        <div class="menu-admin-list">

            <div class="menu-admin-item">

                <div class="menu-admin-image">🍜</div>

                <div class="menu-admin-info">
                    <strong>Mie Spesial</strong>
                    <span>Makanan</span>
                    <b>Rp15.000</b>
                </div>

                <div class="menu-admin-actions">
                    <button class="edit-menu-button">Edit</button>
                    <button class="delete-menu-button">Hapus</button>
                </div>

            </div>

            <div class="menu-admin-item">

                <div class="menu-admin-image">🌶️</div>

                <div class="menu-admin-info">
                    <strong>Mie Level</strong>
                    <span>Makanan</span>
                    <b>Rp17.000</b>
                </div>

                <div class="menu-admin-actions">
                    <button class="edit-menu-button">Edit</button>
                    <button class="delete-menu-button">Hapus</button>
                </div>

            </div>

            <div class="menu-admin-item">

                <div class="menu-admin-image">🍢</div>

                <div class="menu-admin-info">
                    <strong>Sosis Bakar</strong>
                    <span>Snack</span>
                    <b>Rp10.000</b>
                </div>

                <div class="menu-admin-actions">
                    <button class="edit-menu-button">Edit</button>
                    <button class="delete-menu-button">Hapus</button>
                </div>

            </div>

            <div class="menu-admin-item">

                <div class="menu-admin-image">🥤</div>

                <div class="menu-admin-info">
                    <strong>Es Teh</strong>
                    <span>Minuman</span>
                    <b>Rp5.000</b>
                </div>

                <div class="menu-admin-actions">
                    <button class="edit-menu-button">Edit</button>
                    <button class="delete-menu-button">Hapus</button>
                </div>

            </div>

        </div>

    </div>

</div>


<!-- AB3. JAVASCRIPT CRUD MENU ADMIN -->

<script>
    const halamanAdminMenu =
        document.querySelector(".admin-menu-page");

    const tombolKembaliAdminMenu =
        document.querySelector(".admin-menu-back");

    const tombolTambahMenu =
        document.querySelector(".add-menu-button");

    const daftarMenuAdmin =
        document.querySelector(".menu-admin-list");


    // TOMBOL TAMBAH MENU
    tombolTambahMenu.addEventListener("click", function () {

        const nama = prompt("Masukkan nama menu:");

        if (!nama) {
            return;
        }

        const harga = prompt("Masukkan harga menu:");

        if (!harga) {
            return;
        }

        const kategori = prompt(
            "Masukkan kategori (Makanan / Snack / Minuman):"
        );

        if (!kategori) {
            return;
        }

        const menuBaru =
            document.createElement("div");

        menuBaru.className = "menu-admin-item";

        menuBaru.innerHTML = `
            <div class="menu-admin-image">
                🍽️
            </div>

            <div class="menu-admin-info">
                <strong>${nama}</strong>
                <span>${kategori}</span>
                <b>Rp${Number(harga).toLocaleString("id-ID")}</b>
            </div>

            <div class="menu-admin-actions">
                <button class="edit-menu-button">
                    Edit
                </button>

                <button class="delete-menu-button">
                    Hapus
                </button>
            </div>
        `;

        daftarMenuAdmin.appendChild(menuBaru);

        aktifkanTombolMenu(menuBaru);

        alert("Menu berhasil ditambahkan!");

    });


    // FUNGSI EDIT DAN HAPUS
    function aktifkanTombolMenu(menu) {

        const tombolEdit =
            menu.querySelector(".edit-menu-button");

        const tombolHapus =
            menu.querySelector(".delete-menu-button");


        // EDIT MENU
        tombolEdit.addEventListener("click", function () {

            const namaLama =
                menu.querySelector(".menu-admin-info strong");

            const hargaLama =
                menu.querySelector(".menu-admin-info b");

            const kategoriLama =
                menu.querySelector(".menu-admin-info span");


            const namaBaru =
                prompt(
                    "Ubah nama menu:",
                    namaLama.textContent
                );

            if (namaBaru) {
                namaLama.textContent = namaBaru;
            }


            const hargaBaru =
                prompt(
                    "Ubah harga menu:",
                    hargaLama.textContent
                        .replace("Rp", "")
                        .replace(/\./g, "")
                );

            if (hargaBaru) {
                hargaLama.textContent =
                    "Rp" +
                    Number(hargaBaru)
                        .toLocaleString("id-ID");
            }


            const kategoriBaru =
                prompt(
                    "Ubah kategori:",
                    kategoriLama.textContent
                );

            if (kategoriBaru) {
                kategoriLama.textContent =
                    kategoriBaru;
            }

            alert("Menu berhasil diperbarui!");

        });


        // HAPUS MENU
        tombolHapus.addEventListener("click", function () {

            const nama =
                menu.querySelector(
                    ".menu-admin-info strong"
                ).textContent;

            const yakin =
                confirm(
                    "Hapus menu " +
                    nama +
                    "?"
                );

            if (yakin) {

                menu.remove();

                alert(
                    "Menu berhasil dihapus!"
                );

            }

        });

    }


    // AKTIFKAN TOMBOL PADA MENU YANG SUDAH ADA
    document
        .querySelectorAll(".menu-admin-item")
        .forEach(function (menu) {

            aktifkanTombolMenu(menu);

        });


    // KEMBALI KE DASHBOARD
    tombolKembaliAdminMenu.addEventListener(
        "click",
        function () {

            halamanAdminMenu.style.display = "none";
            document.querySelector(".admin-page")
                .style.display = "block";

        }
    );

</script>


<!-- AB4. HUBUNGKAN DASHBOARD ADMIN KE KELOLA MENU -->

<script>
    const tombolKelolaMenu =
        document.querySelector(".admin-menu-card");

    tombolKelolaMenu.addEventListener("click", function () {

        document.querySelector(".admin-page").style.display = "none";

        halamanAdminMenu.style.display = "block";

    });
</script><?php /**PATH C:\xampp\htdocs\QResto\resources\views/admin/menu.blade.php ENDPATH**/ ?>