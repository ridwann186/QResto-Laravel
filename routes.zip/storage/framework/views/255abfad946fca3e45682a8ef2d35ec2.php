
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard - QResto</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin.css')); ?>">
    <style>
        .admin-page {
            display: block !important;
            width: 100%;
            min-height: 100vh;
            background: #f7f7f7;
        }

        .admin-menu-card {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            text-align: left;
            width: 100%;
            padding: 20px;
            border: 1px solid #eee;
            border-radius: 15px;
            background: white;
            cursor: pointer;
            text-decoration: none;
            color: inherit;
        }

        .admin-menu-card span {
            font-size: 25px;
            margin-bottom: 10px;
        }

        .admin-menu-card small {
            color: #888;
            margin-top: 5px;
        }

        .admin-menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 14px;
        }

        .admin-back {
            color: #244b3b;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="admin-page">

    <div class="admin-header">
        <div>
            <p class="admin-label">QResto</p>
            <h2>Admin Dashboard</h2>
        </div>

        <a class="admin-back" href="<?php echo e(route('pelanggan.home')); ?>">
            Keluar Admin
        </a>
    </div>

    <div class="admin-content">

        <div class="admin-section">
            <div class="admin-section-title">
                <div>
                    <h3>Kelola Restoran</h3>
                    <p>Akses fitur administrasi QResto</p>
                </div>
            </div>

            <div class="admin-menu-grid">

                <a href="<?php echo e(route('admin.menu')); ?>" class="admin-menu-card">
                    <span>🍜</span>
                    <strong>Kelola Menu</strong>
                    <small>Tambah dan ubah menu</small>
                </a>

                <a href="<?php echo e(route('admin.pesanan')); ?>" class="admin-menu-card">
                    <span>📋</span>
                    <strong>Pesanan</strong>
                    <small>Lihat semua pesanan</small>
                </a>

                <a href="<?php echo e(route('admin.meja')); ?>" class="admin-menu-card">
                    <span>🪑</span>
                    <strong>Meja & QR</strong>
                    <small>Kelola meja dan QR Code</small>
                </a>

                <a href="<?php echo e(route('admin.laporan')); ?>" class="admin-menu-card">
                    <span>📊</span>
                    <strong>Laporan</strong>
                    <small>Lihat laporan restoran</small>
                </a>

            </div>
        </div>

        <div class="admin-section">
            <div class="admin-section-title">
                <div>
                    <h3>Informasi</h3>
                    <p>Panel pengelolaan restoran QResto</p>
                </div>
            </div>

            <div class="admin-stat-card">
                <strong>Selamat datang di QResto Admin!</strong>
                <p>Silakan pilih fitur administrasi yang ingin dibuka.</p>
            </div>
        </div>

    </div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\QResto\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>