<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PelangganControllers;
use App\Http\Controllers\KasirControllers;
use App\Http\Controllers\AdminControllers;
use App\Http\Controllers\DapurControllers;


// ================= PELANGGAN =================
Route::prefix('pelanggan')->name('pelanggan.')->group(function () {
    // Halaman utama
    Route::get('/', [PelangganControllers::class, 'home'])
        ->name('home');

    // QR khusus Take Away
    Route::get('/takeaway', [PelangganControllers::class, 'takeaway'])
        ->name('takeaway');

    // QR khusus setiap meja
    Route::get('/meja/{nomorMeja}', [PelangganControllers::class, 'meja'])
        ->name('meja');
});

// Halaman utama website
Route::get('/', function () {
    return redirect()->route('pelanggan.home');
});


// ================= KASIR =================
Route::prefix('kasir')->name('kasir.')->group(function () {
    Route::get('/', [KasirControllers::class, 'scan'])->name('index');
    Route::get('/scan', [KasirControllers::class, 'scan'])->name('scan');
    Route::get('/pesanan', [KasirControllers::class, 'pesanan'])->name('pesanan');
});

// ================= ADMIN =================
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [AdminControllers::class, 'dashboard'])->name('dashboard');
    Route::get('/menu', [AdminControllers::class, 'menu'])->name('menu');
    Route::get('/pesanan', [AdminControllers::class, 'pesanan'])->name('pesanan');
    Route::get('/meja', [AdminControllers::class, 'meja'])->name('meja');
    Route::get('/laporan', [AdminControllers::class, 'laporan'])
    ->name('laporan');
});

// ================= DAPUR =================
Route::prefix('dapur')->name('dapur.')->group(function () {
    Route::get('/', [DapurControllers::class, 'index'])->name('index');
});